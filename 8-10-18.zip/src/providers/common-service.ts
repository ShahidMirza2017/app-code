import { Storage } from '@ionic/storage';
import { HttpHeaders } from '@angular/common/http';

export class CommonService {
    public httpOptions: any;
    constructor( public storage: Storage ) {
    }
    setHeaders(): Promise<any> {
        return this.storage.get( 'access_token' ).then(( value ) => {
            this.httpOptions = {
                headers: new HttpHeaders( {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + value
                } )
            };
            return value;
        } );
    };
    
}
