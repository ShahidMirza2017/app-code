import { Injectable } from '@angular/core';

import {
    HttpClient,
    HttpErrorResponse
} from '@angular/common/http';
import { Storage } from '@ionic/storage';
import { UserData } from './user-data';
import { Observable } from 'rxjs/Observable';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import { catchError } from 'rxjs/operators';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';
import { API_PATH } from './constants';
import { CommonService } from './common-service';
import { Transfer } from '@ionic-native/transfer';
@Injectable()
export class ShiftOfficerService extends CommonService {
    data: any;
    labelAttribute: string;

    constructor(
        public http: HttpClient,
        public user: UserData,
        public storage: Storage,
        public transfer: Transfer
    ) {
        super( storage );
    }
    loadShiftOfficer(): any{
        const url = `${ API_PATH }/shift-officers`;
        return this.http.get( url, this.httpOptions )
            .pipe(
            catchError( this.handleError )
            );
    }
    createReport( data: any ): Observable<any> {
        return this.http.post( `${ API_PATH }/daily-reports/store`, data, this.httpOptions ).pipe(
            catchError( this.handleError )
        );
    }

    loadBatches(): any{
        const url = `${ API_PATH }/batches`;
        return this.http.get( url, this.httpOptions )
            .pipe(
            catchError( this.handleError )
            );
    }
    extendShift( data: any ): Observable<any> {
         const url = `${ API_PATH }/shift-officers/${ data.batch }`;
        return this.http.put( url, data, this.httpOptions )
            .pipe(
            catchError( this.handleError )
            );
    }
    findOfficer(sdate){
         const url = `${ API_PATH }/shift-officers/search?shift_date=`+sdate;
        return this.http.get( url, this.httpOptions )
            .pipe(
            catchError( this.handleError )
            );
    }

    private handleError( error: HttpErrorResponse ) {
        //        if ( error.error instanceof ErrorEvent ) {
        //            // A client-side or network error occurred. Handle it accordingly.
        //            console.error( 'An error occurred:', error.error.message );
        //        } else {
        //            // The backend returned an unsuccessful response code.
        //            // The response body may contain clues as to what went wrong,
        //            console.error(
        //                `Backend returned code ${ error.status }, ` +
        //                `body was: ${ error.error }` );
        //        }
        // return an ErrorObservable with a user-facing error message
        return new ErrorObservable( error.error );
    }
}

