import { Injectable } from '@angular/core';
//import { Http, Response } from '@angular/http';
import { Events } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import { catchError } from 'rxjs/operators';
import { UserOptions } from '../interfaces/user-options';
import { API_PATH } from './constants';
import { CommonService } from './common-service';
import { HttpHeaders } from '@angular/common/http';
@Injectable()
export class UserService extends CommonService {
    public readonly HAS_LOGGED_IN = 'hasLoggedIn';
    public readonly HAS_SEEN_TUTORIAL = 'hasSeenTutorial';
    constructor( public http: HttpClient,
        public events: Events,
        public storage: Storage ) {
        super( storage );
    }

    login( data: UserOptions ): Observable<any> {
        return this.http.post( `${ API_PATH }/login`, data )

            //            .map(( res: any ) => {
            //                this.storage.set( this.HAS_LOGGED_IN, true );
            //                this.storage.set( 'username', username );
            //                this.events.publish( 'user:login' );
            //                return res.json()
            //            } )
            .pipe(
            catchError( this.handleError )
            );

    };
    fcm_token_reg( data ): Observable<any> {
        return this.http.post( `${ API_PATH }/user/update-details`, data, this.httpOptions)

            .pipe(
            catchError( this.handleError )
            );

    };

    notificationHistory( page = 1): Observable<any> {
        return this.http.get( `${ API_PATH }/order-instructions?page=`+page, this.httpOptions )
            .pipe( catchError( this.handleError ) );
    }

    getUser( token ): Observable<any> {
        const httpOptions = {
            headers: new HttpHeaders( {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            } )
        };
        return this.http.get( `${ API_PATH }/get-user`, httpOptions )

            //            .map(( res: any ) => {
            //                this.storage.set( this.HAS_LOGGED_IN, true );
            //                this.storage.set( 'username', username );
            //                this.events.publish( 'user:login' );
            //                return res.json()
            //            } )
            .pipe(
            catchError( this.handleError )
            );

    }
    logout(): void {
        this.storage.remove( this.HAS_LOGGED_IN );
        this.storage.remove( 'username' );
        this.storage.remove( 'access_token' );
        this.storage.remove( 'user_info' );
        
        this.events.publish( 'user:logout' );
    };
    private handleError( error: HttpErrorResponse ) {
        if ( error.error instanceof ErrorEvent ) {
            // A client-side or network error occurred. Handle it accordingly.
            console.error( 'An error occurred:', error.error.message );
        } else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong,
            console.error(
                `Backend returned code ${ error.status }, ` +
                `body was: ${ error.error }` );
        }
        // return an ErrorObservable with a user-facing error message
        return new ErrorObservable( error.error );
    };

    setUsername( username: string ): void {
        this.storage.set( 'username', username );
    };

    getUsername(): Promise<string> {
        return this.storage.get( 'username' ).then(( value ) => {
            return value;
        } );
    };

    hasLoggedIn(): Promise<boolean> {
        return this.storage.get( this.HAS_LOGGED_IN ).then(( value ) => {
            return value === true;
        } );
    };

    checkHasSeenTutorial(): Promise<string> {
        return this.storage.get( this.HAS_SEEN_TUTORIAL ).then(( value ) => {
            return value;
        } );
    };
}
