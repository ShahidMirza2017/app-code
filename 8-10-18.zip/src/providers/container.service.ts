import { Injectable } from '@angular/core';

import {
    HttpClient,
    HttpErrorResponse,
    HttpHeaders
} from '@angular/common/http';
import { Storage } from '@ionic/storage';
import { UserData } from './user-data';
import { Observable } from 'rxjs/Observable';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import { catchError } from 'rxjs/operators';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';
import { API_PATH, PATH } from './constants';
import { CommonService } from './common-service';
import { Transfer, TransferObject } from '@ionic-native/transfer';
@Injectable()
export class ContainerService extends CommonService {
    data: any;
    labelAttribute: string;
public httpOptions: any;
    constructor(
        public http: HttpClient,
        public user: UserData,
        public storage: Storage,
        public transfer: Transfer
    ) {
        super( storage );
        storage.get( 'access_token' ).then(( value ) => {
            this.httpOptions = {
                headers: new HttpHeaders( {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + value
                } )
            };
           
        } );
    }

    loadContainers( page = 1 ): Observable<any> {
        const url = `${ API_PATH }/containers?page=` + page;
        return this.http.get( url, this.httpOptions )
            .pipe(
            catchError( this.handleError )
            );
    }
    getContainerDetails( id: any ): any {
        return this.http.get( `${ API_PATH }/containers/${ id }`, this.httpOptions ).pipe(
            catchError( this.handleError )
        );
    }
    createContainer( data: any ): Observable<any> {
        return this.http.post( `${ API_PATH }/containers/store`, data, this.httpOptions ).pipe(
            catchError( this.handleError )
        );
    }
    uploadExamination( data: any, completePath: string, token ): Promise<any> {
        var filename = data['files[]'];
        var targetPath = data['files[]'];
        data['fileName'] = filename;
        if(token){
            console.log('Token available');
        }
        var options = {
            fileKey: "files[]",
            fileName: filename,
            chunkedMode: false,
            mimeType: "multipart/form-data",
            params: data,
            // headers: {
            //     'Content-Type': 'application/x-www-form-urlencoded',
            //     'Authorization': 'Bearer ' + token
            // }
        };
        const fileTransfer: TransferObject = this.transfer.create();
        // Use the FileTransfer to upload the image 
        return fileTransfer.upload( targetPath, `${ API_PATH }/containers/store-examined`, options ).then((result)=>{
            console.log("result"+JSON.stringify(result))
        },(err)=>{
            console.log("error"+JSON.stringify(err))
        })
    }
    multipleImg(fd){
        // 	var request = new XMLHttpRequest();
		// request.open('POST', `${ API_PATH }/containers/store-scanned`);
        // request.send(fd);
        console.log(JSON.stringify(fd));
        
         return new Promise((resolve, reject) => {
            this.http.post(`${ API_PATH }/containers/store-examined`, fd)
            .subscribe(res => {
                resolve(res);
            //success 
            }, (err) => {
                reject(err);
                //fail
            });
        });
        
    }
    uploadScannedImages( data: any, completePath: string, token ): Promise<any> {
        var filename = data['files[]'];
        var targetPath = completePath;
        data['fileName'] = filename;
        if(token){
            console.log('Token available');
        }
        var options = {
            fileKey: "files[]",
            fileName: filename,
            chunkedMode: false,
            mimeType: "multipart/form-data",
            params: data,
            // headers: {
            //     'Content-Type': 'application/x-www-form-urlencoded',
            //     'Authorization': 'Bearer ' + token
            // }
        };
        const fileTransfer: TransferObject = this.transfer.create();
        // Use the FileTransfer to upload the image 
        return fileTransfer.upload( targetPath, `${ API_PATH }/containers/store-scanned`, options );
    }
    searchContainer( keyword: string ): any {
        return this.http.get( `${ API_PATH }/search/containers?q=` + keyword, this.httpOptions ).pipe(
            catchError( this.handleError )
        );
    }
    filterContainer( keyword: string ): any {
        return this.http.get( `${ API_PATH }/containers/search?` + keyword, this.httpOptions ).pipe(
            catchError( this.handleError )
        );
    }
    filterScanned( keyword: string ): any {
        return this.http.get( `${ API_PATH }/scanned-images?` + keyword, this.httpOptions ).pipe(
            catchError( this.handleError )
        );
    }
    filterExamined( keyword: string ): any {
        return this.http.get( `${ API_PATH }/examined-images?` + keyword, this.httpOptions ).pipe(
            catchError( this.handleError )
        );
    }
    examinedChapter( keyword: string ): any {
        return this.http.get( `${ API_PATH }/examined/search-images?chapter_id=` + keyword, this.httpOptions ).pipe(
            catchError( this.handleError )
        );
    }
    getImageLibrary( page = 1 ) {
        const url = `${ API_PATH }/image-library?page=` + page;
        return this.http.get( url, this.httpOptions ).pipe(
            catchError( this.handleError )
        );

    }
    getScannedImages( page = 1 ): any {
        const url = `${ API_PATH }/scanned-images?page=` + page;
        return this.http.get( url, this.httpOptions ).pipe(
            catchError( this.handleError )
        );

    }

    imageEPath(){
        return `${ PATH }/storage/containers/examined/`; 
    }

    loadSpecialWatch(): any {
        return this.http.get( `${ API_PATH }/special-watch`, this.httpOptions ).pipe(
            catchError( this.handleError )
        );
    }
    markAsSpecialWatch( data, val: any ): any {
        let url = `${ API_PATH }/containers/mark-special-watch`;
        if ( val ) {
            url = `${ API_PATH }/containers/unmark-special-watch`;
        }
        return this.http.post( url, data, this.httpOptions ).pipe(
            catchError( this.handleError )
        );
    }
    loadChapterheading(): any {
        const url = `${ API_PATH }/containers/chapter-headings`;
        return this.http.get( url, this.httpOptions )
            .pipe(
            catchError( this.handleError )
            );
    }
    searchChapterheading( keyword: string ): any {
        return this.http.get( `${ API_PATH }/containers/chapter-headings?q=` + keyword, this.httpOptions ).pipe(
            catchError( this.handleError )
        );
    }
    searchCfsName( keyword: string ): any {
        return this.http.get( `${ API_PATH }/containers/cfs-names?q=` + keyword, this.httpOptions ).pipe(
            catchError( this.handleError )
        );
    }
    private handleError( error: HttpErrorResponse ) {
        //        if ( error.error instanceof ErrorEvent ) {
        //            // A client-side or network error occurred. Handle it accordingly.
        //            console.error( 'An error occurred:', error.error.message );
        //        } else {
        //            // The backend returned an unsuccessful response code.
        //            // The response body may contain clues as to what went wrong,
        //            console.error(
        //                `Backend returned code ${ error.status }, ` +
        //                `body was: ${ error.error }` );
        //        }
        // return an ErrorObservable with a user-facing error message
        return new ErrorObservable( error.error );
    }
}

