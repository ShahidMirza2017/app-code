import { Injectable } from '@angular/core';

import {
    HttpClient,
    HttpErrorResponse
} from '@angular/common/http';
import { Storage } from '@ionic/storage';
import { UserData } from './user-data';
import { Observable } from 'rxjs/Observable';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import { catchError } from 'rxjs/operators';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';
import { API_PATH } from './constants';
import { CommonService } from './common-service';
import { Transfer } from '@ionic-native/transfer';
@Injectable()
export class ReportService extends CommonService {
    data: any;
    labelAttribute: string;

    constructor(
        public http: HttpClient,
        public user: UserData,
        public storage: Storage,
        public transfer: Transfer
    ) {
        super( storage );
    }

    createReport( data: any ): Observable<any> {
        return this.http.post( `${ API_PATH }/daily-reports/store`, data, this.httpOptions ).pipe(
            catchError( this.handleError )
        );
    }

    loadReport(): any {
        const url = `${ API_PATH }/daily-reports`;
        return this.http.get( url, this.httpOptions )
            .pipe(
            catchError( this.handleError )
            );
    }
    loadGraphMonth(month: any ): any {
    const url = `${ API_PATH }/graph/month-wise-scanning-data?month=${month}`;
    return this.http.get( url, this.httpOptions )
        .pipe(
        catchError( this.handleError )
        );
    }
    loadGraph(): any {
    const url = `${ API_PATH }/graph/scanned-graph`;
    return this.http.get( url, this.httpOptions )
        .pipe(
        catchError( this.handleError )
        );
    }
loadGraphMisMatch(): any {
    const url = `${ API_PATH }/graph/mismatch-graph`;
    return this.http.get( url, this.httpOptions )
        .pipe(
        catchError( this.handleError )
        );
    }
    loadRealTimeCFS(page = 1,date_month): any {
    const url = `${ API_PATH }/cfs-reports?page=` + page + `&date=` + date_month;
    return this.http.get( url, this.httpOptions )
        .pipe(
        catchError( this.handleError )
        );
    }
    loadRealTimeScanned(page = 1): any {
    const url = `${ API_PATH }/scanning-reports?page=` + page;
    return this.http.get( url, this.httpOptions )
        .pipe(
        catchError( this.handleError )
        );
    }
    createContainer( data: any ): Observable<any> {
        return this.http.post( `${ API_PATH }/containers/store`, data, this.httpOptions ).pipe(
            catchError( this.handleError )
        );
    }
    private handleError( error: HttpErrorResponse ) {
        //        if ( error.error instanceof ErrorEvent ) {
        //            // A client-side or network error occurred. Handle it accordingly.
        //            console.error( 'An error occurred:', error.error.message );
        //        } else {
        //            // The backend returned an unsuccessful response code.
        //            // The response body may contain clues as to what went wrong,
        //            console.error(
        //                `Backend returned code ${ error.status }, ` +
        //                `body was: ${ error.error }` );
        //        }
        // return an ErrorObservable with a user-facing error message
        return new ErrorObservable( error.error );
    }
}

