
export const PATH = 'http://52.230.121.34';
export const API_PATH = 'https://csdchennai.in/api';
// export const PATH = 'http://178.128.32.82/';
// export const API_PATH = 'http://178.128.32.82/api';
