import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage';
import {
    HttpClient,
    HttpErrorResponse
} from '@angular/common/http';
import { Transfer, TransferObject } from '@ionic-native/transfer';
import { UserData } from './user-data';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';
import { API_PATH } from './constants';
import { CommonService } from './common-service';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import { catchError } from 'rxjs/operators';
@Injectable()
export class CaseRegisterService extends CommonService {
    data: any;
    labelAttribute: string;
    constructor(
        public http: HttpClient,
        public user: UserData,
        private transfer: Transfer,
        public storage: Storage,
    ) {
        super(storage);
    }

    loadCases(page = 1): any {
        return this.http.get(`${API_PATH}/cases?page=` + page, this.httpOptions)
            .pipe(
            catchError(this.handleError)
            );
    }
    getCaseDetails(id: any): any {
        return this.http.get(`${API_PATH}/cases/${id}`, this.httpOptions).pipe(
            catchError(this.handleError)
        );
    }
    createCase(data: any): any {
        return this.http.post(`${API_PATH}/cases`, data, this.httpOptions).pipe(
            catchError(this.handleError)
        );
    }
    createCaseImages(data: any, completePath: string, t: string): Promise<any> {
        var filename = data['files[]'];
        var targetPath = completePath;
        data['fileName'] = filename;
        if (t) {
            console.log('toekn avaliable');
        }
        var options = {
            fileKey: "files[]",
            fileName: filename,
            chunkedMode: false,
            mimeType: "multipart/form-data",
            params: data,
            // headers: {
            //     'Content-Type': 'application/x-www-form-urlencoded',
            //     'Authorization': 'Bearer ' + token
            // }
        };
        const fileTransfer: TransferObject = this.transfer.create();
        // Use the FileTransfer to upload the image 
        return fileTransfer.upload(targetPath, `${API_PATH}/cases`, options);
    }
    private handleError(error: HttpErrorResponse) {
        //        if ( error.error instanceof ErrorEvent ) {
        //            // A client-side or network error occurred. Handle it accordingly.
        //            console.error( 'An error occurred:', error.error.message );
        //        } else {
        //            // The backend returned an unsuccessful response code.
        //            // The response body may contain clues as to what went wrong,
        //            console.error(
        //                `Backend returned code ${ error.status }, ` +
        //                `body was: ${ error.error }` );
        //        }
        // return an ErrorObservable with a user-facing error message
        return new ErrorObservable(error.error);
    }
}
