import { NgModule } from '@angular/core';
import { ObjkeyPipe } from './objkey/objkey';
@NgModule({
	declarations: [ObjkeyPipe],
	imports: [],
	exports: [ObjkeyPipe]
})
export class PipesModule {
	static forRoot() {
      return {
          ngModule: PipesModule,
          providers: [],
      };
   }
}
