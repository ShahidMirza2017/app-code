import { Pipe, PipeTransform } from '@angular/core';

/**
 * Generated class for the ObjkeyPipe pipe.
 *
 * See https://angular.io/api/core/Pipe for more info on Angular Pipes.
 */
@Pipe({
  name: 'objkey',
  pure: false
})
export class ObjkeyPipe implements PipeTransform {
  
  transform(value, args:string[]) : any {
    let keys = [];
    for (let key in value) {
      keys.push(key);
    }
    return keys;
  }
}
