import { Component, ViewChild, OnInit } from '@angular/core';

import {App,
    Events,
    MenuController,
    ToastController,
    Nav,
    Platform,
    AlertController
} from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';

import { Storage } from '@ionic/storage';
import 'chart.js/src/chart.js';
import { AccountPage } from '../pages/account/account';
import { HomePage } from '../pages/home/home';
import { LoginPage } from '../pages/login/login';
import { TabsPage } from '../pages/tabs-page/tabs-page';
import { ContainerPage } from '../pages/container/container';

import { ReportPage } from '../pages/report/report';
import { GraphReportPage } from '../pages/report/graph-report';
import { CreateReportPage } from '../pages/report/create-report';

import { ScannedImagesPage } from '../pages/scanned-images/scanned-images';
import { ExaminedImagesPage } from '../pages/examined-images/examined-images';
import { AddExaminedImagesPage } from '../pages/add-examined-images/add-examined-images';
import { AddScannedmagesPage } from '../pages/add-scanned-images/add-scanned-images';
import { CaseRegisterPage } from '../pages/case-register/case-register';
import { AddCaseRegisterPage } from '../pages/add-case-register/add-case-register';
import { SpecialWatchPage } from '../pages/special-watch/special-watch';
import { CreateContainerPage } from '../pages/container/create-container';
import { ContainerFilterPage } from '../pages/container-filter/container-filter';
import { ShiftOfficerPage } from '../pages/shift-officer/shift-officer';

import { UserService } from '../providers/user-service';
import { UserData } from '../providers/user-data';

import { FCM } from '@ionic-native/fcm';
import { PhonegapLocalNotification } from '@ionic-native/phonegap-local-notification';

export interface PageInterface {
    title: string;
    name: string;
    component: any;
    icon: string;
    logsOut?: boolean;
    index?: number;
    tabName?: string;
    tabComponent?: any;
}

@Component({
    templateUrl: 'app.template.html'
})
export class ConferenceApp implements OnInit {

    @ViewChild(Nav) nav: Nav;
    public isLoggedIn = false;
    loggedInPages: PageInterface[] = [


        //        { title: 'Home', name: 'HomePage', component: HomePage, icon: 'home' },
        //        { title: 'Scanned Images', name: 'ScannedImagesPage', component: ScannedImagesPage, icon: 'aperture' },
        //        { title: 'Examined Images', name: 'ExaminedImagesPage', component: ExaminedImagesPage, icon: 'images' },
        //        { title: 'Containers', name: 'ContainerPage', component: ContainerPage, icon: 'logo-dropbox' },
        //        { title: 'Create Container', name: 'CreateContainerPage', component: CreateContainerPage, icon: 'add' },
        //        { title: 'Reports', name: 'ContainerPage', component: ContainerPage, icon: 'open' },
        //        { title: 'Case Register', name: 'CaseRegisterPage', component: CaseRegisterPage, icon: 'briefcase' },
        //        { title: 'Shift Officer Details', name: 'ContainerPage', component: ContainerPage, icon: 'open' },
        //        { title: 'Special Watch', name: 'SpecialWatchPage', component: SpecialWatchPage, icon: 'open' },
        //        //
        //        { title: 'Add Case Register', name: 'AddCaseRegisterPage', component: AddCaseRegisterPage, icon: 'briefcase' },
        //        { title: 'Add Scanned Images', name: 'AddScannedmagesPage', component: AddScannedmagesPage, icon: 'camera' },
        //        { title: 'Add Examined Images', name: 'AddExaminedImagesPage', component: AddExaminedImagesPage, icon: 'photos' },
        //        { title: 'Mark Special Watch', name: 'ContainerPage', component: ContainerPage, icon: 'open' },
        //
        //
        //        // old
        // { title: 'Account', name: 'AccountPage', component: AccountPage, icon: 'person' },
        // { title: 'Logout', name: 'TabsPage', component: TabsPage, icon: 'log-out', logsOut: true }
    ];


    rootPage: any;
    alert: any;
    fcm_token: any = "";
    backButtonPressedOnceToExit = false;
    constructor(
        public app: App,
        public events: Events,
        public userService: UserService,
        public userData: UserData,
        public menu: MenuController,
        public platform: Platform,
        public storage: Storage,
        public splashScreen: SplashScreen,
        private alertCtrl: AlertController,
        private toastCtrl: ToastController,
        private fcm: FCM,
        private localNotification: PhonegapLocalNotification
    ) {

        // Check if the user has already seen the tutorial
        // this.storage.get('hasSeenTutorial')
        //     .then((hasSeenTutorial) => {
        //         if (hasSeenTutorial) {
        //             this.rootPage = TabsPage;
        //         } else {
        //             this.rootPage = TutorialPage;
        //         }
        //         this.platformReady()
        //     });
        this.rootPage = TabsPage;
        this.platformReady()
        // load the conference data

        // decide which menu items should be hidden by current login status stored in local storage
        this.userService.hasLoggedIn().then((hasLoggedIn) => {
            if (hasLoggedIn) {
                this.isLoggedIn = true;
                // this.enableMenu(hasLoggedIn === true);
                this.enableMenu(false);
                this.nav.setRoot(HomePage);
            } else {
                this.enableMenu(false);
                this.nav.setRoot(LoginPage);
            }
        });

        // this.enableMenu(true);

        this.listenToLoginEvents();

        platform.ready().then(() => {
            fcm.getToken().then(token=>{
                this.fcm_token = token;
                console.log("fcm_token:"+token);
                })

                fcm.onNotification().subscribe(data=>{
                if(data.wasTapped){
                    console.log("Received in background");
                } else {
                    console.log("Received in foreground"+data);
                };
                this.localNotification.requestPermission().then(
                        (permission) => {
                            if (permission === 'granted') {

                            // Create the notification
                            this.localNotification.create(data.title, {
                                //tag: 'message1',
                                body: data.body,
                                icon: 'assets/icon/favicon.ico'
                            });

                            }
                        }
                        );
                })

                fcm.onTokenRefresh().subscribe(token=>{
                this.fcm_token = token;
                })
            // Okay, so the platform is ready and our plugins are available.
            // Here you can do any higher level native things you might need

            platform.registerBackButtonAction(() => {

            //     let nav = this.app.getActiveNav();
            //   let view = nav.getActive().instance.pageName;

            //     console.log(nav.getActive().name);
                // this.app.goBack();
                
            //   if (nav.getActive().name == "ModalCmp"){
            //       nav.getActive().dismiss();
            //   }else
                //uncomment this and comment code below to to show toast and exit app
                if (this.backButtonPressedOnceToExit) {
                    this.platform.exitApp();
                } else if (this.nav.canGoBack()) {
                    // this.nav.pop({});
                     const overlayView = this.app._appRoot._overlayPortal._views[0];
                    if (overlayView && overlayView.dismiss) {
                        overlayView.dismiss();
                    } else {
                        this.app.goBack();
                    }
                } else {
                    this.showToast();
                    this.backButtonPressedOnceToExit = true;
                    setTimeout(() => {

                        this.backButtonPressedOnceToExit = false;
                    }, 2000)
                }
            });
        });

    }
    ngOnInit(): void {
        this.userData.loadRoles().then((value) => {
            console.log("userrole",value);
            //            this.loggedInPages = data;
            if (value) {
                if(this.fcm_token != "")
                this.userService.setHeaders().then(() => {
                    this.userService.fcm_token_reg({fcm_token: this.fcm_token}).subscribe(( data ) => {
                        console.log(data);
                    } );
                } );
                this.loggedInPages.push({ title: 'Home', name: 'HomePage', component: HomePage, icon: 'home' });
           //     this.loggedInPages.push({ title: 'Case Register', name: 'CaseRegisterPage', component: CaseRegisterPage, icon: 'briefcase' });
             //   this.loggedInPages.push({ title: 'Add Case Register', name: 'AddCaseRegisterPage', component: AddCaseRegisterPage, icon: 'briefcase' });
               
                for (let i = 0; i < value.roles[0].permissions.length; i++) {
                    switch (value.roles[0].permissions[i].name) {

                        case 'view-container-images':
                            this.loggedInPages.push({ title: 'View Scanned Images', name: 'ScannedImagesPage', component: ScannedImagesPage, icon: 'aperture' });
                            this.loggedInPages.push({ title: 'View Examined Images', name: 'ExaminedImagesPage', component: ExaminedImagesPage, icon: 'images' });
                            break;
                        case 'view-containers':
                            this.loggedInPages.push({ title: 'Containers', name: 'ContainerPage', component: ContainerPage, icon: 'logo-dropbox' });
                            break;
                        case 'create-containers':
                            this.loggedInPages.push({ title: 'Create Container', name: 'CreateContainerPage', component: CreateContainerPage, icon: 'add' });
                            break;
                        case 'view-graph-report':
                            this.loggedInPages.push({ title: 'Graph Reports', name: 'GraphReportPage', component: GraphReportPage, icon: 'open' });
                            break;
                        case 'view-daily-report':
                            this.loggedInPages.push({ title: 'Daily Reports', name: 'ReportPage', component: ReportPage, icon: 'open' });
                            this.loggedInPages.push({ title: 'Create Daily Report', name: 'CreateReportPage', component: CreateReportPage, icon: 'add' });
                            break;
                        case 'view-cases':
                            this.loggedInPages.push({ title: 'Case Register', name: 'CaseRegisterPage', component: CaseRegisterPage, icon: 'briefcase' });
                            break;
                        case 'create-cases':
                            this.loggedInPages.push({ title: 'Add Case Register', name: 'AddCaseRegisterPage', component: AddCaseRegisterPage, icon: 'briefcase' });
                            break;
                        case 'view-shift-officer':
                            this.loggedInPages.push({ title: 'Shift Officer Details', name: 'ShiftOfficerPage', component: ShiftOfficerPage, icon: 'open' });
                            break;
                        case 'view-special-watch':

                            this.loggedInPages.push({ title: 'Special Watch', name: 'SpecialWatchPage', component: SpecialWatchPage, icon: 'open' });
                            break;

                        case 'upload-scanned-images':
                            this.loggedInPages.push({ title: 'Add Scanned Images', name: 'AddScannedmagesPage', component: AddScannedmagesPage, icon: 'camera' });
                            break;
                        case 'upload-examined-images':
                            this.loggedInPages.push({ title: 'Add Examined Images', name: 'AddExaminedImagesPage', component: AddExaminedImagesPage, icon: 'photos' });
                            break;
                        case 'mark-special-watch':
                            this.loggedInPages.push({ title: 'Mark Special Watch', name: 'ContainerPage', component: ContainerPage, icon: 'open' });
                            break;
                        default:
                            break;
                    }
                }
                this.loggedInPages.push({ title: 'Account', name: 'AccountPage', component: AccountPage, icon: 'person' },
                    { title: 'Logout', name: 'TabsPage', component: TabsPage, icon: 'log-out', logsOut: true });
                //          
                // this.loggedInPages = pages;
            }
        });
    }
    showAlert() {
        this.alert = this.alertCtrl.create({
            title: 'Exit?',
            message: 'Do you want to exit the app?',
            buttons: [
                {
                    text: 'Cancel',
                    role: 'cancel',
                    handler: () => {
                        this.alert = null;
                    }
                },
                {
                    text: 'Exit',
                    handler: () => {
                        this.platform.exitApp();
                    }
                }
            ]
        });
        this.alert.present();
    }

    showToast() {
        let toast = this.toastCtrl.create({
            message: 'Press Again to exit',
            duration: 2000,
            position: 'bottom'
        });

        toast.onDidDismiss(() => {
            console.log('Dismissed toast');
        });

        toast.present();
    }
    openPage(page: PageInterface) {
        let params = {};

        // the nav component was found using @ViewChild(Nav)
        // setRoot on the nav to remove previous pages and only have this page
        // we wouldn't want the back button to show in this scenario
        if (page.index) {
            params = { tabIndex: page.index };
        }

        // If we are already on tabs just change the selected tab
        // don't setRoot again, this maintains the history stack of the
        // tabs even if changing them from the menu
        if (this.nav.getActiveChildNavs().length && page.index != undefined) {
            this.nav.getActiveChildNavs()[0].select(page.index);
        } else {
            // Set the root of the nav with params if it's a tab index
            if(page.name == "HomePage")
                this.nav.setRoot("HomePage");
            else
            this.nav.push(page.name, params).catch((err: any) => {
                console.log(`Didn't set nav root: ${err}`);
            });
        }

        if (page.logsOut === true) {
            // Give the menu time to close before changing to logged out
            this.userService.logout();
        }
    }
    /**
     * test
     */
    // openTutorial() {
    //     this.nav.setRoot(TutorialPage);
    // }

    listenToLoginEvents() {
        this.events.subscribe('user:login', () => {

            this.nav.setRoot(HomePage);
            // this.enableMenu(true);
             this.enableMenu(false);
        });

        //        this.events.subscribe( 'user:signup', () => {
        //            this.enableMenu( false );
        //        } );

        this.events.subscribe('user:logout', () => {
            this.nav.setRoot(LoginPage);
            this.enableMenu(false);
        });
    }

    enableMenu(loggedIn: boolean) {

        this.isLoggedIn = loggedIn;
        this.menu.enable(loggedIn, 'loggedInMenu');
    }

    platformReady() {
        // Call any initial plugins when ready
        this.platform.ready().then(() => {
            this.splashScreen.hide();
        });
    }

    //    isActive( page: PageInterface ) {
    //        let childNav = this.nav.getActiveChildNavs()[0];
    //        // Tabs are a special case because they have their own navigation
    //        if ( childNav ) {
    //            if ( childNav.getSelected() && childNav.getSelected().root === page.tabComponent ) {
    //                return 'primary';
    //            }
    //            return;
    //        }
    //
    //        if ( this.nav.getActive() && this.nav.getActive().name === page.name ) {
    //            return 'primary';
    //        }
    //        return;
    //    }
}
