import { BrowserModule } from '@angular/platform-browser';
//import { HttpModule } from '@angular/http';
import { NgModule, ErrorHandler, NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

import { HttpClientModule } from '@angular/common/http';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';

import { InAppBrowser } from '@ionic-native/in-app-browser';
import { SplashScreen } from '@ionic-native/splash-screen';
import { ImagePicker } from '@ionic-native/image-picker';

import { ChartsModule } from 'ng2-charts';

import { IonicStorageModule } from '@ionic/storage';
import { PdfViewerModule } from 'ng2-pdf-viewer';

import { ConferenceApp } from './app.component';

import { PopoverPage } from '../pages/about-popover/about-popover';
import { AccountPage } from '../pages/account/account';
import { LoginPage } from '../pages/login/login';
import { SignupPage } from '../pages/signup/signup';
import { HomePage } from '../pages/home/home';
import { TabsPage } from '../pages/tabs-page/tabs-page';

import { SpecialWatchPage } from '../pages/special-watch/special-watch';
import { SpecialWatchDetailPage } from '../pages/special-watch-details/special-watch-details';


import { UserService } from '../providers/user-service';
import { UserData } from '../providers/user-data';
import { ContainerService } from '../providers/container.service'
import { CaseRegisterService } from '../providers/case-register.service'
import { ReportService } from '../providers/report.service'
import { ShiftOfficerService } from '../providers/shift-officer.service'
// ng
import { BasePage } from '../pages/base-page';
import { ContainerPage } from '../pages/container/container';
import { ContainerDetailPage } from '../pages/container-detail/container-detail';
import { ReportPage } from '../pages/report/report';
import { GraphReportPage } from '../pages/report/graph-report';
import { CreateReportPage } from '../pages/report/create-report';
import { ScannedImagesPage } from '../pages/scanned-images/scanned-images';
import { ExaminedImagesPage } from '../pages/examined-images/examined-images';
import { AddExaminedImagesPage } from '../pages/add-examined-images/add-examined-images';
import { AddScannedmagesPage } from '../pages/add-scanned-images/add-scanned-images';
import { AddCaseRegisterPage } from '../pages/add-case-register/add-case-register';
import { CaseRegisterPage } from '../pages/case-register/case-register';
import { CaseRegisterDetailPage } from '../pages/case-register-detail/case-register-detail';
import { CreateContainerPage } from '../pages/container/create-container';
import { ContainerFilterPage } from '../pages/container-filter/container-filter';
import { ShiftOfficerPage } from '../pages/shift-officer/shift-officer';
import { ShiftOfficerDetailsPage } from '../pages/shift-officer/shift-officer-details';
import { ShiftOfficerFindPage } from '../pages/shift-officer/shift-officer-find';
import { ShiftExtendPage } from '../pages/shift-officer/shift-extend';
import { NotificationPage } from '../pages/notification/notification';
import { RealTimeExaminationPage } from '../pages/real-time/real-time-examination';
import { RealTimeScannedPage } from '../pages/real-time/real-time-scanned';

import { PdfViewerPage } from '../pages/notification/pdf-viewer';
import { ChapterWisePage } from '../pages/chapter-wise/chapter-wise';
import { ChapterWiseDetailPage } from '../pages/chapter-wise-detail/chapter-wise-detail';

import { Ng2CompleterModule } from "ng2-completer";
import { File } from '@ionic-native/file';
import { Transfer } from '@ionic-native/transfer';
import { FilePath } from '@ionic-native/file-path';
import { Camera } from '@ionic-native/camera';

import { FCM } from '@ionic-native/fcm';
import { PhonegapLocalNotification } from '@ionic-native/phonegap-local-notification';

import { IonicImageViewerModule } from 'ionic-img-viewer';

// import { AutoCompleteModule } from 'ionic2-auto-complete';
import { AutocompleteComponent } from '../components/auto-complete';
import { ChapterAutocompleteComponent } from '../components/chapter-auto-complete/chapter-auto-complete';
import { CfsNameAutocompleteComponent } from '../components/cfs_name-auto-complete/cfs_name-auto-complete';
import {Base64} from "@ionic-native/base64";

import { ObjkeyPipe } from '../pipes/objkey/objkey';

import { PipesModule } from '../pipes/pipes.module';

const pageImports = [
    ConferenceApp,
    AccountPage,
    LoginPage,
    PopoverPage,
    SignupPage,
    HomePage,
    TabsPage,
    ContainerPage,
    ReportPage,
    GraphReportPage,
    BasePage,
    ContainerDetailPage,
    ScannedImagesPage,
    ExaminedImagesPage,
    AddExaminedImagesPage,
    AddScannedmagesPage,
    AddCaseRegisterPage,
    CaseRegisterPage,
    CaseRegisterDetailPage,
    AutocompleteComponent,
    ChapterAutocompleteComponent,
    CfsNameAutocompleteComponent,
    SpecialWatchPage,
    SpecialWatchDetailPage,
    CreateContainerPage,
    ContainerFilterPage,
    CreateReportPage,
    ShiftOfficerPage,
    ShiftOfficerDetailsPage,
    ShiftExtendPage,
    NotificationPage,
    PdfViewerPage,
    ChapterWisePage,
    ChapterWiseDetailPage,
    RealTimeScannedPage,
    RealTimeExaminationPage,
    ShiftOfficerFindPage,
    // ObjkeyPipe
]
@NgModule( {
    declarations: [
        ...pageImports
    ],
    imports: [
        // AutoCompleteModule,
        BrowserModule,
        PdfViewerModule,
        CommonModule,
        // HttpModule,
        HttpClientModule,
        ReactiveFormsModule,
        Ng2CompleterModule,
        IonicModule.forRoot( ConferenceApp, {}, {
            links: [
                { component: TabsPage, name: 'TabsPage', segment: 'tabs-page' },
                { component: SignupPage, name: 'SignupPage', segment: 'signup' },
                // NG
                { component: LoginPage, name: 'LoginPage', segment: 'login' },
                { component: AccountPage, name: 'AccountPage', segment: 'account' },
                { component: HomePage, name: 'HomePage', segment: 'home' },
                { component: ContainerPage, name: 'ContainerPage', segment: 'container' },
                { component: CreateContainerPage, name: 'CreateContainerPage', segment: 'createContainer' },
                { component: ReportPage, name: 'ReportPage', segment: 'report' },
                { component: RealTimeExaminationPage, name: 'RealTimeExaminationPage', segment: 'realTimeExamination' },
                { component: RealTimeScannedPage, name: 'RealTimeScannedPage', segment: 'realTimeScanned' },
                { component: CreateReportPage, name: 'CreateReportPage', segment: 'createReport' },
                { component: GraphReportPage, name: 'GraphReportPage', segment: 'graphReport' },
                { component: ShiftOfficerPage, name: 'ShiftOfficerPage', segment: 'shiftOfficer' },
                { component: ShiftOfficerDetailsPage, name: 'ShiftOfficerDetailsPage', segment: 'shiftOfficerDetails' },
                { component: ShiftOfficerFindPage, name: 'ShiftOfficerFindPage', segment: 'shiftOfficerFind' },
                { component: ShiftExtendPage, name: 'ShiftExtendPage', segment: 'shiftExtend' },
                { component: ContainerDetailPage, name: 'ContainerDetail', segment: 'containerDetail/:containerId' },
                { component: ScannedImagesPage, name: 'ScannedImagesPage', segment: 'scannedImages' },
                { component: ExaminedImagesPage, name: 'ExaminedImagesPage', segment: 'examinedImages' },
                { component: ChapterWisePage, name: 'ChapterWisePage', segment: 'chapterWise' },
                { component: AddExaminedImagesPage, name: 'AddExaminedImagesPage', segment: 'addExaminedImages' },
                { component: AddScannedmagesPage, name: 'AddScannedmagesPage', segment: 'addScannedImages' },
                { component: AddCaseRegisterPage, name: 'AddCaseRegisterPage', segment: 'addCaseRegister' },
                { component: CaseRegisterPage, name: 'CaseRegisterPage', segment: 'caseRegister' },
                { component: CaseRegisterDetailPage, name: 'CaseRegisterDetailPage', segment: 'caseDetail/:caseId' },
                { component: SpecialWatchPage, name: 'SpecialWatchPage', segment: 'specialWatch' },
                { component: SpecialWatchDetailPage, name: 'SpecialWatchDetailPage', segment: 'specialWatchDetail/:containerId' },
                { component: NotificationPage, name: 'NotificationPage', segment: 'notificationHistory' },
                { component: PdfViewerPage, name: 'PdfViewerPage', segment: 'pdfviewer' },

            ]
        } ),
         ChartsModule,
        IonicStorageModule.forRoot(),
        PipesModule.forRoot(),
        IonicImageViewerModule
    ],
    bootstrap: [IonicApp],
    entryComponents: [
        ...pageImports
    ],
    providers: [
        { provide: ErrorHandler, useClass: IonicErrorHandler },
        UserService,
        UserData,
        ContainerService,
        CaseRegisterService,
        ReportService,
        ShiftOfficerService,
        InAppBrowser,
        SplashScreen,
        StatusBar,
        File,
        Transfer,
        ImagePicker,
        Camera,
        FilePath,
        DatePipe,
        FCM,
        Base64,
        PhonegapLocalNotification
    ],
    schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
} )
export class AppModule { }
