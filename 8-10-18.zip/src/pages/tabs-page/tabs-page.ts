import { Component } from '@angular/core';
import { NavParams } from 'ionic-angular';
import { NavController } from 'ionic-angular';
import { LoginPage } from '../login/login';
import { HomePage } from '../home/home';
import { UserData } from '../../providers/user-data';
@Component({
  templateUrl: 'tabs-page.html'
})
export class TabsPage {
  mySelectedIndex: number;

  constructor(
    navParams: NavParams,
    nav: NavController,
    public userData: UserData) {
    this.mySelectedIndex = navParams.data.tabIndex || 0;
    this.userData.hasLoggedIn().then((hasLoggedIn) => {
      if (hasLoggedIn) {
        nav.setRoot(HomePage);
      } else {
        nav.setRoot(LoginPage);
      }
    });
  }

}
