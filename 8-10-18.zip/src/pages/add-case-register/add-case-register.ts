import { Component, OnInit } from '@angular/core';
import {
    NavController,
    ToastController,
    Platform,
    LoadingController,
    Loading,
    ActionSheetController
} from 'ionic-angular';
import { ContainerService } from '../../providers/container.service';
import { CaseRegisterService } from '../../providers/case-register.service';
import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms'
import { CaseRegisterPage } from '../case-register/case-register';
import { FilePath } from '@ionic-native/file-path';
import { Camera } from '@ionic-native/camera';
import { File } from '@ionic-native/file';
import { UserData } from '../../providers//user-data';
declare var cordova: any;

@Component( {
    selector: 'page-add-case-register',
    templateUrl: 'add-case-register.html'
} )
export class AddCaseRegisterPage implements OnInit {
    title = 'Add Case Register';
    formData: FormGroup;
    // image
    lastImage: string = null;
    loading: Loading;
    constructor(
        public containerService: ContainerService,
        public caseRegisterService: CaseRegisterService,
        private fb: FormBuilder,
        public navCtrl: NavController,
        public toastCtrl: ToastController,
        public platform: Platform,
        public loadingCtrl: LoadingController,
        private camera: Camera,
        private file: File,
        private filePath: FilePath,
        public actionSheetCtrl: ActionSheetController,
        private userData: UserData
    ) {
        this.formData = this.fb.group( {
            user_id: new FormControl( '', Validators.required ),
            container_id: new FormControl( '', Validators.required ),
            cfs_name: new FormControl( '', Validators.required ),
            scanning_result: new FormControl( '', Validators.required ),
            igm_description: new FormControl( '', Validators.required ),
            importer_name: new FormControl( '', Validators.required ),
            date_of_examination: new FormControl( '', Validators.required ),
            be_no_date: new FormControl( '', Validators.required ),
            case_details: new FormControl( '', Validators.required ),
            additional_revenue: new FormControl( '', [] ),
            'files[]': new FormControl( '', Validators.required )
        } );
    }
    ngOnInit() {

    }
    onSelected( item: any ) {
        // let con = item['container_number'] + '=> IGM Number:' + item['igm_number'] + '=> CFS Name:' + item['cfs_name'];
        this.formData.get( 'cfs_name' ).setValue( item.cfs_name );
        this.formData.get( 'container_id' ).setValue( item['id'] );
        this.userData.getUserId().then(( id ) => {
            this.formData.get( 'user_id' ).setValue( id );
        } );
    }
    submit() {
        if ( this.formData.valid ) {
            this.uploadDataAndImages( this.formData.value );
        } else {
            Object.keys( this.formData.controls ).forEach( field => {
                const control = this.formData.get( field );
                control.markAsTouched( { onlySelf: true } );
            } );
        }
    }

    uploadDataAndImages( data: any ): any {
        this.loading = this.loadingCtrl.create( {
            content: 'Uploading..',
        } );
        this.loading.present();
        const completePath = this.pathForImage( data['files[]'] );
        this.caseRegisterService.setHeaders().then((val) => {
            this.caseRegisterService.createCaseImages( data, completePath, val ).then(() => {
                this.loading.dismissAll();
                this.formData.reset();
                this.navCtrl.push( CaseRegisterPage );
                this.presentToast( 'Data uploaded successfully' );
            }, () => {
                this.loading.dismissAll()
                this.presentToast( 'Error while uploading file/Image is too big.' );
            } )
        } );
    }
    isValid( key, validation = 'required' ) {
        return this.formData.get( key ).hasError( validation ) &&
            ( this.formData.get( key ).dirty ||
                this.formData.get( key ).touched )
    }
    public presentActionSheet() {
        let actionSheet = this.actionSheetCtrl.create( {
            title: 'Image Source',
            buttons: [
                {
                    text: 'Gallery',
                    handler: () => {
                        this.takePicture( this.camera.PictureSourceType.PHOTOLIBRARY );
                    }
                },
                {
                    text: 'Camera',
                    handler: () => {
                        this.takePicture( this.camera.PictureSourceType.CAMERA );
                    }
                },
                {
                    text: 'Cancel',
                    role: 'cancel'
                }
            ]
        } );
        actionSheet.present();
    }
    public takePicture( sourceType ) {
        // Create options for the Camera Dialog
        var options = {
            quality: 100,
            sourceType: sourceType,
            saveToPhotoAlbum: false,
            correctOrientation: true
        };

        // Get the data of an image
        this.camera.getPicture( options ).then(( imagePath ) => {
            // Special handling for Android library
            if ( this.platform.is( 'android' ) && sourceType === this.camera.PictureSourceType.PHOTOLIBRARY ) {
                this.filePath.resolveNativePath( imagePath )
                    .then( filePath => {
                        let correctPath = filePath.substr( 0, filePath.lastIndexOf( '/' ) + 1 );
                        let currentName = imagePath.substring( imagePath.lastIndexOf( '/' ) + 1, imagePath.lastIndexOf( '?' ) );
                        this.copyFileToLocalDir( correctPath, currentName, this.createFileName() );
                    } );
            } else {
                var currentName = imagePath.substr( imagePath.lastIndexOf( '/' ) + 1 );
                var correctPath = imagePath.substr( 0, imagePath.lastIndexOf( '/' ) + 1 );
                this.copyFileToLocalDir( correctPath, currentName, this.createFileName() );
            }
        }, ( err ) => {
            console.log( 'Error Data' );
            console.log( err );
            this.presentToast( 'Error while selecting image.' );
        } );
    }
    private createFileName() {
        var d = new Date(),
            n = d.getTime(),
            newFileName = n + ".jpg";
        return newFileName;
    }

    // Copy the image to a local folder
    private copyFileToLocalDir( namePath, currentName, newFileName ) {
        this.file.copyFile( namePath, currentName, cordova.file.dataDirectory, newFileName ).then( success => {
            console.log( 'Success Data' );
            console.log( success );
            this.lastImage = newFileName;
            this.lastImage = newFileName;
            this.formData.get( 'files[]' ).setValue( this.lastImage );
        }, error => {
            console.log( 'add-scanned-images :: copyFileToLocalDir :: Error Data' );

            console.log( error );
            this.presentToast( 'Error while storing file.' );
        } );
    }
    private presentToast( text ) {
        let toast = this.toastCtrl.create( {
            message: text,
            duration: 3000,
            position: 'bottom'
        } );
        toast.present();
    }
    // Always get the accurate path to your apps folder
    public pathForImage( img ) {
        if ( img === null ) {
            return '';
        } else {
            return cordova.file.dataDirectory + img;
        }
    }
}
