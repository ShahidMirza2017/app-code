import { Component, OnInit } from '@angular/core';
import { NavController } from 'ionic-angular';
import { UserService } from '../providers/user-service';
import { LoginPage } from './login/login';
//import { ContainerPage } from './container/container';
//import { AddCaseRegisterPage } from './add-case-register/add-case-register';
//import { AddExaminedImagesPage } from './add-examined-images/add-examined-images';
//import { AddScannedmagesPage } from './add-scanned-images/add-scanned-images';
import { PageInterface } from '../app/app.component';
@Component( {
    selector: 'base',
    template: ''
} )
export class BasePage implements OnInit {
    addItems: PageInterface[];
    constructor(
        public userService: UserService,
        public nav: NavController ) {
    }
    ngOnInit() {
        this.addItems = [
            //            //
            //            { title: 'Add Case Register', name: 'AddCaseRegisterPage', component: AddCaseRegisterPage, icon: 'briefcase' },
            //            { title: 'Add Scanned Images', name: 'AddScannedmagesPage', component: AddScannedmagesPage, icon: 'camera' },
            //            { title: 'Add Examined Images', name: 'AddExaminedImagesPage', component: AddExaminedImagesPage, icon: 'photos' },
            //            { title: 'Mark Special Watch', name: 'ContainerPage', component: ContainerPage, icon: 'open' },
            //
        ];
    }
    logout() {
        this.userService.logout();
        this.nav.setRoot( LoginPage );
    }
    openPage( page: PageInterface ) {
        let params = {};

        if ( page.index ) {
            params = { tabIndex: page.index };
        }
        this.nav.setRoot( page.name, params ).catch(( err: any ) => {
            console.log( `Didn't set nav root: ${ err }` );
        } );
        if ( page.logsOut === true ) {
            // Give the menu time to close before changing to logged out
            this.userService.logout();
        }
    }

}
