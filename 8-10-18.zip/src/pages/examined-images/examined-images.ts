import {Component, ViewChild} from '@angular/core';
import {
    NavController, Refresher,
    LoadingController,
    ModalController, Slides
} from 'ionic-angular';
import { HomePage } from '../home/home';
import { ContainerService } from '../../providers/container.service';
import { UserService } from '../../providers/user-service';
import { BasePage } from '../base-page';
import { PageInterface } from '../../app/app.component';
import { UserData } from '../../providers/user-data';
import { ContainerFilterPage } from '../container-filter/container-filter';
@Component( {
    selector: 'page-examined-images',
    templateUrl: 'examined-images.html'
} )
export class ExaminedImagesPage extends BasePage {
    session: any;
    cDetails: any;
    page = 1;
    noOfPages = 0;
    totalItem = 0;

    isFilter=0;
    paramKeys:any;

    keyword:any;
    filterItemsamedata:any = [];
    checkContainerData:any = [];
    myfilterData: any = [];
    @ViewChild(Slides)slides:Slides;
    constructor(
        public containerService: ContainerService,
        private navController: NavController,
        public loadingCtrl: LoadingController,
        public modalCtrl: ModalController,
        public user: UserService,
        public userData: UserData,
    ) {
        super(user,navController);
        this.cDetails = [];
    }

    ionViewWillEnter() {
        let loading = this.loadingCtrl.create( {
            content: `Please wait...`
        } );
        loading.present();
        this.containerService.setHeaders().then(() => {
            this.containerService.getImageLibrary()
                .subscribe(( data: any ) => {
                    this.cDetails = this.cDetails.concat( data.data );
                    this.filetrData();
                    if ( data.meta ) {
                        this.noOfPages = data.meta.pagination.total_pages;
                        this.totalItem = data.meta.pagination.total;
                    }
                    loading.dismiss();
                } );
        } );
    }
    setBackButtonAction() {
        this.navController.push( HomePage );
    }
    doRefresh( refresher: Refresher ) {
        this.page=1;
        this.cDetails=[]
        this.containerService.setHeaders().then(() => {
            this.containerService.getImageLibrary(this.page)
                .subscribe(( data: any ) => {
                    setTimeout(() => {
                        this.ionViewWillEnter()
                        refresher.complete();
                    }, 500 );

                } );
        } );
    }
    doInfinite( infiniteScroll: any ) {
        this.page += 1;
        if(this.isFilter == 1){
            let keys = this.paramKeys;
            keys +="page="+this.page;
            this.containerService.setHeaders().then(() => {
                this.containerService.filterExamined(keys).subscribe(( data: any ) => {
                 setTimeout(() => {
                        infiniteScroll.complete();
                    this.cDetails = this.cDetails.concat(data.data);
                    if ( data.meta ) {
                        this.noOfPages = data.meta.pagination.total_pages;
                        this.totalItem = data.meta.pagination.total;
                    }
                    }, 100 );
                } );
            } );
        }else{
            this.containerService.setHeaders().then(() => {
                this.containerService.getImageLibrary( this.page )
                    .subscribe(( data: any ) => {
                        setTimeout(() => {
                            this.cDetails = this.cDetails.concat(data.data);
                            // console.log(JSON.stringify(data))
                            this.filetrData();
                            if ( data.meta ) {
                                this.noOfPages = data.meta.pagination.total_pages;
                                this.totalItem = data.meta.pagination.total;
                            }
                            infiniteScroll.complete();
                        }, 100 );
                    } );

            } );
        }

    }
    filetrData(){
        //this.myfilterData = [];
        
        this.cDetails.forEach(item => {
            if(this.checkContainer(item.container.container_number))
            this.myfilterData.push(this.filterItemsame(item.container.container_number));
        });
        console.log("FilterData:::",this.myfilterData);
    }
    filterItemsamecheck(searchTerm){
        return this.filterItemsamedata.filter((item) => {
            return item.container.container_number.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
        });
        
    }
    checkContainer(searchTerm){
        let checkContainerDatalen = this.checkContainerData.filter((item) => {
            // console.log("checkdata",item);
            return item.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
        });
        if(checkContainerDatalen.length == 0)
            return true;
        else
            return false;
    }
    filterItemsame(searchTerm){
       // console.log(searchTerm,this.filterItemsamecheck(searchTerm));
         this.checkContainerData.push(searchTerm);
    //    console.log("checkdata",this.checkContainer(searchTerm));
       return this.cDetails.filter((item) => {
            return item.container.container_number.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
        });    
    }
    
    home(){
        this.navController.setRoot( HomePage );
    }
    openPage(page: PageInterface) {
        let params = {};

        if (page.index) {
            params = { tabIndex: page.index };
        }
        this.navController.push(page.name, params).catch((err: any) => {
            console.log(`Didn't set nav root: ${err}`);
        });
        if (page.logsOut === true) {
            // Give the menu time to close before changing to logged out
            this.userData.logout();
        }
    }

    openModal() {
    let obj = {filter: 'examined'};
        this.page = 1;
        this.isFilter = 1;
        let myModal = this.modalCtrl.create(ContainerFilterPage,obj);
        myModal.onDidDismiss(keyword => {
            if(keyword != undefined){
                 let monthNames = ["January", "February", "March", "April", "May", "June",
                        "July", "August", "September", "October", "November", "December"];
                this.keyword = keyword;
                this.paramKeys = keyword;
                this.keyword = this.keyword.split('&');
                let keywords="";
                for(let i=0;i<this.keyword.length;i++){
                    let kk = this.keyword[i].split("=");
                    if(kk[0] == "container_number")
                    {
                        keywords +=' / '+ "Container No. - " + kk[1];
                    }
                    if(kk[0] == "scanned_date")
                    {
                        let d = new Date(kk[1]);
                        keywords +=' / '+ "Scanned Date - " + monthNames[d.getMonth()];
                    }
                    if(kk[0] == "shift")
                    {
                        keywords +=' / '+ "Shift - " + kk[1];
                    }
                    if(kk[0] == "date_of_examination")
                    {
                        keywords +=' / '+ "Date of Examination - " + kk[1];
                    }
                    //keywords +=' / '+this.keyword[i].replace('=', ' - ');
                }
                this.keyword = keywords;
                let loading = this.loadingCtrl.create( {
                content: `Please wait...`
            } );
            loading.present();
            this.containerService.setHeaders().then(() => {
                this.containerService.filterExamined(keyword).subscribe(( data: any ) => {
                this.cDetails = data.data;
                    if ( data.meta ) {
                        this.noOfPages = data.meta.pagination.total_pages;
                        this.totalItem = data.meta.pagination.total;
                    }
                loading.dismiss();
                } );
            } );
            
            }
        });
        myModal.present();
    }

    slideToNext(i){

        console.log("Index::: "+i)
        this.slides.slideNext();
    }

    slideToPrev(){
        this.slides.slidePrev();
    }
}
