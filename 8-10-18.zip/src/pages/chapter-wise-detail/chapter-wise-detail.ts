import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the ChapterWiseDetailPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-chapter-wise-detail',
  templateUrl: 'chapter-wise-detail.html',
})
export class ChapterWiseDetailPage {
  title:any = "";
  data:any;
  constructor(public navCtrl: NavController, public navParams: NavParams) {
    if(navParams.get('data') != null){
      this.title = navParams.get('title');
      this.data = navParams.get('data');
      // console.log(this.data.data);
    }
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ChapterWiseDetailPage');
  }

}
