import { Component } from '@angular/core';
import { NavParams } from 'ionic-angular';

import { ContainerService } from '../../providers/container.service';

@Component( {
    selector: 'page-special-watch-detail',
    templateUrl: 'special-watch-details.html'
} )
export class SpecialWatchDetailPage {
    session: any;
    cDetails: any;
    constructor(
        public containerService: ContainerService,
        public navParams: NavParams
    ) { }

    ionViewWillEnter() {
        this.containerService.setHeaders().then(() => {
            this.containerService.getContainerDetails( this.navParams.data.containerId )
                .subscribe(( data: any ) => {
                    this.cDetails = data.data;
                } );
        } );
    }
}
