import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../../providers/user-service';
//import { NavController } from 'ionic-angular';
import { Events } from 'ionic-angular';
import { Storage } from '@ionic/storage';
//import { TabsPage } from '../tabs-page/tabs-page';
import { UserOptions } from '../../interfaces/user-options';
import { ToastController } from 'ionic-angular';


@Component( {
    selector: 'page-user',
    templateUrl: 'login.html'
} )
export class LoginPage implements OnInit {
    login: UserOptions = { employee_id: '', email: '', password: '' };
    submitted = false;
    authForm: FormGroup;
    constructor(
        private userService: UserService,
        //        private navCtrl: NavController,
        private events: Events,
        private storage: Storage,
        private toastCtrl: ToastController
    )
    { }

    ngOnInit() {

this.authForm = new FormGroup({
username: new FormControl('', [Validators.required]),
password: new FormControl('', [Validators.required])
});

}

    onSubmit(value: any): void {
        this.submitted = true;
        if (this.authForm.valid) {
            this.login.email = value.username;
            this.login.employee_id = value.username;
            this.login.password = value.password;
            this.userService.login( this.login )
                .subscribe(( data: any ) => {
                    this.storage.set( this.userService.HAS_LOGGED_IN, true );
                    this.storage.set( 'username', this.login.email );
                    this.storage.set( 'access_token', data.success.token );

                    this.userService.getUser( data.success.token ).subscribe(( info: any ) => {
                        this.storage.set( 'user_info', info.success );
                        this.events.publish( 'user:login' );
                    } );



                    //                    return res.json()
                }, ( error ) => {
                    console.log( 'Error' );
                    this.presentToast( error.error );
                } );
            //            this.navCtrl.push( TabsPage );
        }
    }

    presentToast( msg: string ) {
        let toast = this.toastCtrl.create( {
            message: msg,
            duration: 3000,
            position: 'bottom'
        } );

        toast.onDidDismiss(() => {
            console.log( 'Dismissed toast' );
        } );

        toast.present();
    }

}
