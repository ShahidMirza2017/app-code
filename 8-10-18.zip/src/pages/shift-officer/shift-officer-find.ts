import { Component } from '@angular/core';
import {
    AlertController,
    App,
    ModalController,
    NavController,
    ToastController,
    LoadingController
} from 'ionic-angular';
import { DatePipe } from '@angular/common'

//import { FormControl } from '@angular/forms';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/switchMap';
// import { Chart } from 'chart.js';

import { HomePage } from '../home/home';

// import moment from 'moment';

import { UserService } from '../../providers/user-service';
import { ShiftOfficerService } from '../../providers/shift-officer.service';

//ng
import { BasePage } from '../base-page';
import { PageInterface } from '../../app/app.component';
import { UserData } from '../../providers/user-data';

import { ShiftOfficerDetailsPage } from './shift-officer-details';

@Component( {
    selector: 'page-shift-officer-find',
    templateUrl: 'shift-officer-find.html'
} )
export class ShiftOfficerFindPage extends BasePage {
   
    title = 'Find Shift Officer';
    dailyreport: any = [];
    odailyreport: any = [];
    graphData: any;
    reportDate:any = "";


    constructor(
        public alertCtrl: AlertController,
        public app: App,
        public loadingCtrl: LoadingController,
        public modalCtrl: ModalController,
        public navCtrl: NavController,
        public toastCtrl: ToastController,
        public user: UserService,
        public userData: UserData,
        private shiftOfficerService: ShiftOfficerService,
        public datepipe: DatePipe
    ) {
        super( user, navCtrl );
        
    // this.reportDate = this.datepipe.transform(this.reportDate, 'yyyy-MM-dd');
    }

   

    ionViewDidLoad() {
        // this.loadDailyReport();
       // this.loadGraph();
        
    }
    loadDailyReport() {
        let loading = this.loadingCtrl.create( {
            content: `Please wait...`
        } );
        loading.present();
        this.shiftOfficerService.setHeaders().then(() => {
        this.shiftOfficerService.findOfficer(this.reportDate).subscribe((data: any)=>{
         this.odailyreport = data;
        this.dailyreport = data;
        //this.changeDate(this.reportDate);
        //console.log(this.reportDate);
        loading.dismiss();
        });
    });
    }

    changeDate(reportDate){
        let loading = this.loadingCtrl.create( {
            content: `Please wait...`
        } );
        loading.present();
        this.shiftOfficerService.setHeaders().then(() => {
        this.shiftOfficerService.findOfficer(reportDate).subscribe((data: any)=>{
         this.odailyreport = data;
        this.dailyreport = data;
        loading.dismiss();
        });
    });
    }

    callIT(passedNumber){
    //You can add some logic here
    passedNumber = encodeURIComponent(passedNumber);
     window.location.href = "tel:"+passedNumber;
    }
    getShiftOfficerDetails( officerData: any ) {
        officerData.find = true;
        this.navCtrl.push( ShiftOfficerDetailsPage, { officerData: officerData } );
    }
   
   
    home(){
        this.navCtrl.setRoot( HomePage );
    }
   
    openPage(page: PageInterface) {
        let params = {};

        if (page.index) {
            params = { tabIndex: page.index };
        }
        this.navCtrl.push(page.name, params).catch((err: any) => {
            console.log(`Didn't set nav root: ${err}`);
        });
        if (page.logsOut === true) {
            // Give the menu time to close before changing to logged out
            this.userData.logout();
        }
    }
}
