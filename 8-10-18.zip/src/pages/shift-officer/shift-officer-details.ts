import { Component } from '@angular/core';
import {
    NavController,
    LoadingController,
    NavParams
} from 'ionic-angular';
import { DatePipe } from '@angular/common';

import { ShiftOfficerService } from '../../providers/shift-officer.service';
import { UserService } from '../../providers/user-service';
import { HomePage } from '../home/home';

import { BasePage } from '../base-page';
import { PageInterface } from '../../app/app.component';
import { UserData } from '../../providers/user-data';

import { ContainerFilterPage } from '../container-filter/container-filter';

@Component( {
    selector: 'page-shift-officer-details',
    templateUrl: 'shift-officer-details.html'
} )
export class ShiftOfficerDetailsPage extends BasePage{
    session: any;
    cDetails: any;
    title:any;
    keyword:any;
    searching: any = false;
    searchTerm: string = '';
    window:any;
    yesterday_date:any;
    today_date:any;
    today_time: any;
    today_shift: any;
    constructor(
        public shiftOfficerService: ShiftOfficerService,
        private navController: NavController,
        public loadingCtrl: LoadingController,
        public user: UserService,
        public userData: UserData,
        public datepipe: DatePipe,
        public navParams: NavParams
    ) {
        super( user, navController );
        
        this.cDetails = navParams.data.officerData;
        if(this.cDetails.batch_name != undefined || this.cDetails.batch_name != null)
            this.title = "Batch " + this.cDetails.batch_name;
        else
            this.title = "Batch " + this.cDetails.batch.name;
        console.log(this.cDetails);
        this.today_date=this.datepipe.transform(new Date(), 'yyyy-MM-dd');
        this.today_time=new Date().getHours();
        this.yesterday_date =new Date();
        this.yesterday_date.setDate(this.yesterday_date.getDate() -1);
        this.yesterday_date = this.datepipe.transform(this.yesterday_date, 'yyyy-MM-dd');
        if(this.today_time >= 8 && this.today_time > 20)
        {
            this.today_shift = "night";   
        }else{
            this.today_shift = "day";
        }
    }

    ionViewWillEnter() {
               
    }
   
    inOfferShift(batch:any){
     
   let curshift:any = batch.shift_batch.filter((item) => {
            return item.shift_date.toLowerCase().indexOf(this.today_date) > -1;
        });
       let preshift:any = batch.shift_batch.filter((item) => {
            return item.shift_date.toLowerCase().indexOf(this.yesterday_date) > -1;
        });
        // console.log(curshift);
         if(curshift[0].shift != "off"){
            if(curshift[0].shift == this.today_shift){
                return "OFFICER IN SHIFT";
            }else{
                return "OFFICER IN NEXT SHIFT";
            }
         }else if(preshift[0].shift_date == this.yesterday_date && preshift[0].shift != "off"){
            return "OFFICER PREVIOUS SHIFT";    
        }else{
             return "OFF";
         }
    }

    home(){
        this.navController.setRoot( HomePage );
    }
    openPage(page: PageInterface) {
        let params = {};

        if (page.index) {
            params = { tabIndex: page.index };
        }
        this.navController.push(page.name, params).catch((err: any) => {
            console.log(`Didn't set nav root: ${err}`);
        });
        if (page.logsOut === true) {
            // Give the menu time to close before changing to logged out
            this.userData.logout();
        }
    }

   

    callIT(passedNumber){
    //You can add some logic here
    passedNumber = encodeURIComponent(passedNumber);
     window.location.href = "tel:"+passedNumber;
    }
}
