import { Component } from '@angular/core';
import {
    NavController,
    LoadingController,
    Refresher,
    Platform
} from 'ionic-angular';
import { DatePipe } from '@angular/common';

import { ShiftOfficerService } from '../../providers/shift-officer.service';
import { UserService } from '../../providers/user-service';
import { HomePage } from '../home/home';

import { BasePage } from '../base-page';
import { PageInterface } from '../../app/app.component';
import { UserData } from '../../providers/user-data';

import { ShiftOfficerDetailsPage } from './shift-officer-details';
import { ShiftOfficerFindPage } from './shift-officer-find';
import { ShiftExtendPage } from './shift-extend';

@Component( {
    selector: 'page-shift-officer',
    templateUrl: 'shift-officer.html'
} )
export class ShiftOfficerPage extends BasePage{
    session: any;
    cDetails: any;
    page = 1;
    noOfPages = 0;
    totalItem = 0;
    keyword:any;
    searching: any = false;
    searchTerm: string = '';
    window:any;
    yesterday_date:any;
    today_date:any;
    today_time: any;
    today_shift: any;
    constructor(
        public shiftOfficerService: ShiftOfficerService,
        private navController: NavController,
        public loadingCtrl: LoadingController,
        public user: UserService,
        public userData: UserData,
        public datepipe: DatePipe,
        private platform: Platform
    ) {
        super( user, navController );
    //     console.log('Width: ' + platform.width());
    //   console.log('Height: ' + platform.height());
        this.cDetails = [];
        this.today_date=this.datepipe.transform(new Date(), 'yyyy-MM-dd');
        this.yesterday_date =new Date();
        this.yesterday_date.setDate(this.yesterday_date.getDate() -1);
        this.yesterday_date = this.datepipe.transform(this.yesterday_date, 'yyyy-MM-dd');
        // console.log(this.yesterday_date);
        this.today_time=new Date().getHours();
        console.log(this.today_time);
        if(this.today_time >= 8 && this.today_time > 20)
        {
            this.today_shift = "night";   
        }else{
            this.today_shift = "day";
        }
    }

    inOfferShift(batch:any){
     
   let curshift:any = batch.shift_batch.filter((item) => {
            return item.shift_date.toLowerCase().indexOf(this.today_date) > -1;
        });
    let preshift:any = batch.shift_batch.filter((item) => {
            return item.shift_date.toLowerCase().indexOf(this.yesterday_date) > -1;
        });
        // console.log(curshift);
         if(curshift[0].shift != "off"){
            if(curshift[0].shift == this.today_shift){
                return "OFFICER IN SHIFT";
            }else{
                return "OFFICER IN NEXT SHIFT";
            }
         }else if(preshift[0].shift_date == this.yesterday_date && preshift[0].shift != "off"){
            return "OFFICER PREVIOUS SHIFT";    
        }else{
             return "OFF";
         }
    
    }
    
    ionViewWillEnter() {
        let loading = this.loadingCtrl.create( {
            content: `Please wait...`
        } );
        loading.present();
        this.shiftOfficerService.setHeaders().then(() => {
            this.shiftOfficerService.loadShiftOfficer()
                .subscribe(( data: any ) => {
                    this.cDetails = data;//this.cDetails.concat( data );
                    // console.log(data);
                    if ( data.meta ) {
                        this.noOfPages = data.meta.pagination.total_pages;
                        this.totalItem = data.meta.pagination.total;
                    }
                    loading.dismiss();
                } );
        } );
         
    }
    doRefresh( refresher: Refresher ) {
        this.shiftOfficerService.setHeaders().then(() => {
            this.shiftOfficerService.loadShiftOfficer()
                .subscribe(( data: any ) => {
                    this.cDetails = this.cDetails.concat( data.data );
                    if ( data.meta ) {
                        this.noOfPages = data.meta.pagination.total_pages;
                        this.totalItem = data.meta.pagination.total;
                    }
                    refresher.complete();
                } );
        } );
    }
   
    home(){
        this.navController.setRoot( HomePage );
    }
    openPage(page: PageInterface) {
        let params = {};

        if (page.index) {
            params = { tabIndex: page.index };
        }
        this.navController.push(page.name, params).catch((err: any) => {
            console.log(`Didn't set nav root: ${err}`);
        });
        if (page.logsOut === true) {
            // Give the menu time to close before changing to logged out
            this.userData.logout();
        }
    }


    callIT(passedNumber){
    //You can add some logic here
    passedNumber = encodeURIComponent(passedNumber);
     window.location.href = "tel:"+passedNumber;
    }
    getShiftOfficerDetails( officerData: any ) {
        this.navController.push( ShiftOfficerDetailsPage, { officerData: officerData } );
    }
    getShiftExtend() {
        this.navController.push( ShiftExtendPage);
    }
    shiftOfficerFind(){
        this.navController.push( ShiftOfficerFindPage);
    }
    shortName(name){
        if(name.length > 10){
            if(this.platform.width() > 350)
                return name.slice(0, 15) + "...";
            else
                return name.slice(0, 10) + "...";
        }
        else 
            return name;
    }
    shortName1(name){
        if(name.length > 20){
            if(this.platform.width() > 350)
                return name.slice(0, 25) + "...";
            else
                return name.slice(0, 20) + "...";
        }
        else 
            return name;
    }
}
