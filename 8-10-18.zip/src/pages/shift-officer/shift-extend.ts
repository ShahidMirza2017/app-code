import { Component } from '@angular/core';
import {
    NavController,
    ToastController,
    LoadingController,
    NavParams
} from 'ionic-angular';
import { DatePipe } from '@angular/common';
import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms'
import { ShiftOfficerService } from '../../providers/shift-officer.service';
import { UserService } from '../../providers/user-service';
import { HomePage } from '../home/home';

import { BasePage } from '../base-page';
import { PageInterface } from '../../app/app.component';
import { UserData } from '../../providers/user-data';

import { ShiftOfficerPage } from './shift-officer'

@Component( {
    selector: 'page-shift-extend',
    templateUrl: 'shift-extend.html'
} )
export class ShiftExtendPage extends BasePage{
    title:any;
    window:any;
    today_date:any;
    today_time: any;
    today_shift: any;
    batchId: any;
    batches:any;
    formData: FormGroup;
    constructor(
        public shiftOfficerService: ShiftOfficerService,
        private navController: NavController,
        public toastCtrl: ToastController,
        public loadingCtrl: LoadingController,
        private fb: FormBuilder,
        public user: UserService,
        public userData: UserData,
        public datepipe: DatePipe,
        public navParams: NavParams
    ) {
        super( user, navController );
        
        //this.batchId = navParams.data.batchId;
        this.title = "Shift Extend";
        this.formData = this.fb.group( {
            batch_start_date: new FormControl( '', Validators.required ),
            batch_end_date: new FormControl( '', Validators.required ),
            batch: new FormControl( '', Validators.required ),
        } );
    }
   
    ionViewWillEnter() {
        let loading = this.loadingCtrl.create( {
            content: `Please wait...`
        } );
        loading.present();
        this.shiftOfficerService.setHeaders().then(() => {
            this.shiftOfficerService.loadBatches()
                .subscribe(( data: any ) => {
                    this.batches = data.data;
                    loading.dismiss();
                } );
        } );
         
    }

    onSelected( item: any ) {
        this.formData.get( 'batch_start_date' ).setValue( item['batch_start_date'] ); 
       
    }

     submit() {
        if ( this.formData.valid ) {
            let loading = this.loadingCtrl.create( {
                content: `Please wait...`
            } );
            loading.present();
            this.shiftOfficerService.setHeaders().then(() => {
                this.shiftOfficerService.extendShift( this.formData.value )
                    .subscribe(() => {
                        loading.dismiss();

                        this.showToast( 'Created successfully.' );
                        this.navController.push( ShiftOfficerPage );

                    }, ( er: any ) => {
                        loading.dismiss();
                        this.showToast( 'Something went wrong.' + er.error );
                    } );
            } );
        } else {
            Object.keys( this.formData.controls ).forEach( field => { // {1}
                const control = this.formData.get( field );            // {2}
                control.markAsTouched( { onlySelf: true } );       // {3}
            } );
        }
    }
    private showToast( msg ) {
        let toast = this.toastCtrl.create( {
            message: msg,
            duration: 3000,
            position: 'bottom'
        } );
        toast.present();
    }
    setBackButtonAction() {
        this.navController.setRoot( ShiftOfficerPage );
    }
    home(){
        this.navController.setRoot( HomePage );
    }
    openPage(page: PageInterface) {
        let params = {};

        if (page.index) {
            params = { tabIndex: page.index };
        }
        this.navController.push(page.name, params).catch((err: any) => {
            console.log(`Didn't set nav root: ${err}`);
        });
        if (page.logsOut === true) {
            // Give the menu time to close before changing to logged out
            this.userData.logout();
        }
    }

   

    callIT(passedNumber){
    //You can add some logic here
    passedNumber = encodeURIComponent(passedNumber);
     window.location.href = "tel:"+passedNumber;
    }
}
