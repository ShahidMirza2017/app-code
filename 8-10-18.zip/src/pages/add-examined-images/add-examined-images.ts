import { Component, OnInit } from '@angular/core';
import {
    NavController,
    ActionSheetController,
    ToastController,
    Platform,
    LoadingController,
    Loading,
    Refresher
} from 'ionic-angular';
import { ContainerService } from '../../providers/container.service';
import { UserData } from '../../providers/user-data';

import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms'
import { FilePath } from '@ionic-native/file-path';
import { Camera } from '@ionic-native/camera';
import { File } from '@ionic-native/file';
import { ImagePicker } from '@ionic-native/image-picker';
import { Base64 } from '@ionic-native/base64';

import { ExaminedImagesPage } from '../examined-images/examined-images';

import 'rxjs/add/observable/interval';
import { Observable } from 'rxjs/Rx';
declare var cordova: any;

@Component( {
    selector: 'page-add-examined-images',
    templateUrl: 'add-examined-images.html'
} )
export class AddExaminedImagesPage implements OnInit {
    title = 'Add Examination Images';
    formData: FormGroup;
    myfd: FormData;
    // image
    lastImage: any = [];
    images: any = [];
    loading: Loading;
    testImg:any;
    chapterheadings: any;
    container_img: any;
    scannedData: any;
    cDetails: any =[];
    addform:any = false;
    aip:any =false;
    aip1:any =true;
    page = 1;
    filenames=[];
    itr:number;
    window: any;
    updata = 0;
    upload_size:number;
    img_size:number=0;
    sub:any;
    constructor(
        public containerService: ContainerService,
        private fb: FormBuilder,
        public navCtrl: NavController,
        private camera: Camera,
        private gallery:Camera,
        private imagePicker: ImagePicker,
        private file: File,
        private filePath: FilePath,
        public actionSheetCtrl: ActionSheetController,
        public toastCtrl: ToastController,
        public platform: Platform,
        public loadingCtrl: LoadingController,
        private userData:UserData,
        private base64:Base64
    ) {
        this.formData = this.fb.group( {
            user_id: new FormControl( '', Validators.required ),
            container_id: new FormControl( '', Validators.required ),
            bill_no: new FormControl( '', Validators.required ),
            bill_date: new FormControl( '', Validators.required ),
            date_of_examination: new FormControl( '', Validators.required ),
            chapter_headings: new FormControl( '', Validators.required ),
            description: new FormControl( '', Validators.required ),
            examination_findings: new FormControl( '', Validators.required ),
            discrepancy: new FormControl( '', Validators.required ),
            query1: new FormControl( '', Validators.required ),
            // imgurl: new FormControl( '', Validators.required )
            'files[]':new FormControl('',Validators.required)
        } );
         this.formData.get( 'query1' ).setValue( "sdfsd");
         this.myfd = new FormData();
    }
    ngOnInit() {

    }
    onSelected( item: any ) {

        this.formData.get( 'container_id' ).setValue( item['id'] ); 
        this.container_img = item.scannedImage.data.image;
        this.scannedData = item.scannedImage.data;
        this.userData.getUserId().then(( id ) => {
            this.formData.get( 'user_id' ).setValue( id );
        } );
    }
    onCHSelected( item: any ) {
        this.formData.get( 'chapter_headings' ).setValue( item['name'] ); 
    }
    submit() {
       if ( this.formData.valid ) {
        // this.filenames.forEach((i) => {
        //     //this.formData.get( 'files').setValue(this.file.externalDataDirectory+i);
        //     console.log("Submit Method:: "+this.file.externalDataDirectory+i);
        //     console.log("Sub 2::"+ this.formData.get('files[]'))
        //     this.formData.get('files[]').setValue(this.file.externalDataDirectory+i);
        //     // this.uploadDataAndImages( this.formData.value );
        // });
console.log("size"+this.img_size);
        if(120 >= this.img_size){
            this.upload_size=this.filenames.length;
            this.formData.get('files[]').setValue(this.file.externalDataDirectory+''+this.filenames[this.itr]);
            this.uploadDataAndImages(this.formData.value);
            console.log(this.upload_size);
            console.log(this.itr);
            console.log(this.filenames[this.itr]);
        }else{
                        this.presentToast( 'Images Size must less than 120mb.' );
}

        } else {
            Object.keys( this.formData.controls ).forEach( field => { // {1}
                const control = this.formData.get( field );            // {2}
                control.markAsTouched( { onlySelf: true } );       // {3}
            } );
        }
    }
    uploadDataAndImages( data: any ): any {

        var itrnum=this.itr;
        itrnum=itrnum+1;
        this.loading = this.loadingCtrl.create( {
            content: 'Uploading '+itrnum+' of '+this.upload_size+'.',
        } );
        //if(this.updata == 0)
        if(itrnum<=this.upload_size)
        this.loading.present();
        const completePath =  data['files[]'];
        console.log("completePath",completePath);
        this.containerService.setHeaders().then((token) => {
            console.log("Container Data : "+JSON.stringify(data))
            this.containerService.uploadExamination( data, completePath, token ).then((result) => {
                console.log(JSON.stringify("Container Service  : "+result))
                this.updata++;
                this.itr=this.itr+1;
                if(this.itr<this.upload_size){
                    this.loading.dismissAll()
                    setTimeout(()=>{
                        this.submit()
                    },500)

                }
                else {
                   // if(this.lastImage.length == this.updata){
                        this.loading.dismissAll();
                        this.formData.reset();
                        this.navCtrl.push( ExaminedImagesPage );
                        this.presentToast( 'Data uploaded successfully.' );
                    //}

                }


            }, (e) => {
                console.log(e);
                this.loading.dismissAll()
                this.presentToast( 'Error while uploading file/Image is too big.' );
            } );
        } );
    }
    isValid( key, validation = 'required' ) {
        return this.formData.get( key ).hasError( validation ) &&
            ( this.formData.get( key ).dirty ||
                this.formData.get( key ).touched )
    }
    public presentActionSheet() {
        let actionSheet = this.actionSheetCtrl.create( {
            title: 'Image Source',
            buttons: [
                {
                    text: 'Gallery',
                    handler: () => {
                        // this.takePicture( this.camera.PictureSourceType.PHOTOLIBRARY );
                        this.openImagePicker();
                    }
                },
                // {
                //     text: 'Camera',
                //     handler: () => {
                //         this.takePicture( this.camera.PictureSourceType.CAMERA );
                //     }
                // },
                {
                    text: 'Cancel',
                    role: 'cancel'
                }
            ]
        } );
        actionSheet.present();
    }
openImagePicker(){
    // this.lastImage = [];
    // this.images = [];
    this.itr=0
    let options= {
    }
this.loading = this.loadingCtrl.create( {
            content: 'Uploading..',
        } );
    console.log("Permission Check"+JSON.stringify(this.imagePicker.hasReadPermission()))
    this.imagePicker.requestReadPermission()
    console.log("Permission Check"+JSON.stringify(this.imagePicker.hasReadPermission()))


    this.filenames=[]
        
    this.imagePicker.getPictures(options)
    .then((results) => {
        // this.loading.present();
      console.log(results);
      //console.log(this.file.cacheDirectory.toString())

      //let myimg = results;
      
      for(let i=0;i<results.length;i++){
          //this.lastImage.push(results[i]);
          var currentName = results[i].substr( results[i].lastIndexOf( '/' ) + 1 );
          console.log("current name : "+currentName)
          this.images.push(results[i].toString());
          var d = new Date(),n = d.getTime()
          var newFileName = n+Math.random()*1000+ ".jpg";
          this.filenames.push(newFileName)
          this.file.copyFile(this.file.cacheDirectory, currentName, this.file.externalDataDirectory, newFileName).then((success)=>{
            //   console.log(JSON.stringify(success))
              this.file.readAsDataURL(this.file.externalDataDirectory,this.filenames[i]).then((data)=>{

                //   console.log(JSON.stringify(this.filenames[i]/.size))
                  this.lastImage.push(data)
                  this.images.push(data)
                  console.log("newFileName:: "+ this.filenames[i]);
              },(err)=>{
                  console.log("File DataURL Err"+JSON.stringify(err))

              });
          },(err)=>{
              console.log(JSON.stringify(err))

          })
            
        this.file.resolveLocalFilesystemUrl(results[i]).then((file) =>{
            file.getMetadata((meta) => {
                console.log(meta.size);
                this.img_size += (meta.size/1024)/1024;
console.log(this.img_size);
                // for(let j=0;j<meta.size;j++){
                //     console.log(meta[j].size);
                // }
            }, error => console.log(error))
          }

        )
        // console.log((this.img_size/1024)/1024 + "mb");
        
          // let filePath: string = 'file:///...';
          // this.base64.encodeFile(results[i]).then((base64File: string) => {
          //     //console.log(base64File);
          //     var normalizedBase64Data="data:image/png;base64,"+base64File.replace("data:image/png;base64,data:image/*;charset=utf-8;base64,","")
          //     //var normalizedBase64Data=normalizedBase64Data.replace("\n","")
          //     console.log("Base64Data:: "+normalizedBase64Data.substring(0,10000).replace("data:image/*;charset=utf-8;base64,","").replace(/(\r\n\t|\n|\r\t)/gm,""));
          //     //this.lastImage.push(normalizedBase64Data.replace("data:image/*;charset=utf-8;base64,",""))
          // }, (err) => {
          //     console.log("An Error Occured"+err);
          // });

          this.formData.get( 'files[]' ).setValue( results[i] );
      }
    }, (err) => { console.log("err",err) });
  }

    public openGallery() {
        // Create options for the Camera Dialog
        var options = {
            quality: 10,
            sourceType: this.camera.PictureSourceType.SAVEDPHOTOALBUM,
            saveToPhotoAlbum: false,
            correctOrientation: true,
            encodingType: this.camera.EncodingType.JPEG,
            destinationType: this.camera.DestinationType.DATA_URL,
            targetWidth:720,
            targetHeight:1280
        };

        // Get the data of an image
        this.gallery.getPicture( options ).then(( imageCode ) => {
            console.log( imageCode );
            // Special handling for Android library
            if ( this.platform.is( 'android' )) {
                this.testImg="data:image/png;base64,"+imageCode
                console.log(this.testImg)
                // console.log("Cache Test: "+this.testImg)
                this.lastImage.push(this.testImg)
                var base64Data = this.testImg.replace(/^data:image\/png;base64,/, "");
                var buf = new Buffer(imageCode, 'base64');
                this.savebase64AsImageFile(this.file.externalDataDirectory,"test2.png",base64Data,"data:image/png;base64")
                // var arrayBuf=_base64ToArrayBuffer(base64Data)
                // this.file.writeFile(this.file.dataDirectory,"test.png",arrayBuf,{}).then((result)=>{
                //     console.log(JSON.stringify(result))
                // },(err)=>{
                //     console.log(JSON.stringify(err))
                // })

                // this.filePath.resolveNativePath( imagePath )
                //     .then( filePath => {
                //
                //     } );
            } else {
                // var currentName = imagePath.substr( imagePath.lastIndexOf( '/' ) + 1 );
                // var correctPath = imagePath.substr( 0, imagePath.lastIndexOf( '/' ) + 1 );
                // this.copyFileToLocalDir( correctPath, currentName, this.createFileName() );
            }
        }, ( err ) => {
            console.log( 'Error Data' );
            console.log( err );
            this.presentToast( 'Error while selecting image.' );
        } );

    }


    public b64toBlob(b64Data, contentType, sliceSize) {
        contentType = contentType || '';
        sliceSize = sliceSize || 512;

        var byteCharacters = atob(b64Data);
        var byteArrays = [];

        for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
            var slice = byteCharacters.slice(offset, offset + sliceSize);

            var byteNumbers = new Array(slice.length);
            for (var i = 0; i < slice.length; i++) {
                byteNumbers[i] = slice.charCodeAt(i);
            }

            var byteArray = new Uint8Array(byteNumbers);

            byteArrays.push(byteArray);
        }

        var blob = new Blob(byteArrays, {type: contentType});
        return blob;
    }

    public savebase64AsImageFile(folderpath,filename,content,contentType){
        // Convert the base64 string in a Blob
        var DataBlob = this.b64toBlob(content,contentType,512);

        console.log("Starting to write the file :3");
        this.file.writeFile(folderpath,filename,DataBlob).then((result)=>{
                console.log("Success"+JSON.stringify(result))
                console.log(result["nativeURL"])
            },(err)=>{
                console.log(JSON.stringify(err))
            })

    }


    public takePicture( sourceType ) {
        // Create options for the Camera Dialog
        var options = {
            quality: 100,
            sourceType: sourceType,
            saveToPhotoAlbum: false,
            correctOrientation: true
        };

        // Get the data of an image
        this.camera.getPicture( options ).then(( imagePath ) => {
            console.log( imagePath );
            // Special handling for Android library
            if ( this.platform.is( 'android' ) && sourceType === this.camera.PictureSourceType.PHOTOLIBRARY ) {
                this.filePath.resolveNativePath( imagePath )
                    .then( filePath => {
                        let correctPath = filePath.substr( 0, filePath.lastIndexOf( '/' ) + 1 );
                        let currentName = imagePath.substring( imagePath.lastIndexOf( '/' ) + 1, imagePath.lastIndexOf( '?' ) );
                        this.copyFileToLocalDir( correctPath, currentName, this.createFileName() );
                    } );
            } else {
                var currentName = imagePath.substr( imagePath.lastIndexOf( '/' ) + 1 );
                var correctPath = imagePath.substr( 0, imagePath.lastIndexOf( '/' ) + 1 );
                this.copyFileToLocalDir( correctPath, currentName, this.createFileName() );
            }
        }, ( err ) => {
            console.log( 'Error Data' );
            console.log( err );
            this.presentToast( 'Error while selecting image.' );
        } );
    }
    private createFileName() {
        var d = new Date(),
            n = d.getTime(),
            newFileName = n + ".jpg";
        return newFileName;
    }

    // Copy the image to a local folder
    private copyFileToLocalDir( namePath, currentName, newFileName ) {
        this.file.copyFile( namePath, currentName, cordova.file.dataDirectory, newFileName ).then(( success ) => {
            console.log( success );
            this.lastImage.push(newFileName);
            this.formData.get( 'files[]' ).setValue( this.lastImage );
        }, error => {
            console.log( 'add-examined-images :: copyFileToLocalDir :: Error Data' );
            console.log( error );
            this.presentToast( 'Error while storing file.' );
        } );
    }

    private presentToast( text ) {
        let toast = this.toastCtrl.create( {
            message: text,
            duration: 3000,
            position: 'bottom'
        } );
        toast.present();
    }

    // Always get the accurate path to your apps folder
    public pathForImage( img ) {
        if ( img === null ) {
            return '';
        } else {
            // console.log("cordova",cordova.file.dataDirectory);
            return cordova.file.dataDirectory + img;
        }
    }
    ionViewDidLoad() {
        // this.setFilteredItems();
        this.loadChapterHeading();
     
    }
    loadChapterHeading() {
        let loading = this.loadingCtrl.create( {
            content: `Please wait...`
        } );
        loading.present();
        this.containerService.setHeaders().then(() => {
            this.containerService.loadChapterheading().subscribe(( data: any ) => {
                //console.log(data.data);
                this.chapterheadings = data.data;
             //   this.noOfPages = data.meta.pagination.total_pages;
              //  this.totalItem = data.meta.pagination.total;
                loading.dismiss();
            } );
        } );
    }

    ionViewWillEnter() {
        let loading = this.loadingCtrl.create( {
            content: `Please wait...`
        } );
        loading.present();
        this.containerService.setHeaders().then(() => {
            this.containerService.getScannedImages()
                .subscribe(( data: any ) => {
                    this.cDetails = this.cDetails.concat( data.data );
                    
                    loading.dismiss();
                } );
        } );
            
    }
    doRefresh( refresher: Refresher ) {
        this.containerService.setHeaders().then(() => {
            this.containerService.getScannedImages()
                .subscribe(( data: any ) => {
                    this.cDetails = this.cDetails.concat( data.data );
                    refresher.complete();
                } );
        } );
    }
    doInfinite( infiniteScroll: any ) {
        this.page += 1;
        this.containerService.setHeaders().then(() => {
            this.containerService.getScannedImages( this.page ).subscribe(( data: any ) => {
                setTimeout(() => {
                    infiniteScroll.complete();
                    this.cDetails = this.cDetails.concat( data.data );
                   
                }, 100 );
            } );
        } );

    }
    addoForm(){
        this.addform =true;
    }
    addForm(item){
        this.addform =true;
        this.aip = true;
        this.aip1 =false;
        this.formData.get( 'query1' ).setValue( item.container.container_number +'=> IGM Number:' + item.container.igm_number + '=> CFS Name:' + item.container.cfs_name); 
        this.formData.get( 'container_id' ).setValue( item.container.id ); 
        this.container_img = item.image;
        this.scannedData = item;
        this.userData.getUserId().then(( id ) => {
            this.formData.get( 'user_id' ).setValue( id );
        } );
    }
    aipchange(){
        this.aip1 = true;
    }
}
