import { Component, ViewChild } from '@angular/core';
import {
    AlertController,
    App,
    List,
    ModalController,
    NavController,
    ToastController,
    LoadingController,
    Refresher
} from 'ionic-angular';
import { FormControl } from '@angular/forms';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/switchMap';

import { InAppBrowser } from "@ionic-native/in-app-browser";
import { HomePage } from '../home/home';

// import moment from 'moment';

import { UserService } from '../../providers/user-service';
import { ContainerService } from '../../providers/container.service';

//ng
import { BasePage } from '../base-page';
import { ContainerDetailPage } from '../container-detail/container-detail';
import { ContainerFilterPage } from '../container-filter/container-filter';

import { PageInterface } from '../../app/app.component';
import { UserData } from '../../providers/user-data';

import { PdfViewerPage } from './pdf-viewer';



@Component( {
    selector: 'page-notification',
    templateUrl: 'notification.html'
} )
export class NotificationPage extends BasePage {
    @ViewChild( 'scheduleList', { read: List } ) scheduleList: List;
    @ViewChild( 'containerlist', { read: List } ) containerlist: List;
    title = 'Notifications';
    dayIndex = 0;
    queryText = '';
    segment = 'all';
    excludeTracks: any = [];
    shownSessions: any = [];
    groups: any = [];
    confDate: string;
    searching: any = false;
    searchTerm: string = '';
    searchControl: FormControl;
    myModal:any;

    keyword:any;
    //ng
    containerList: any = [];
    page = 1;
    noOfPages = 0;
    totalItem = 0;
    

    constructor(
        public alertCtrl: AlertController,
        public app: App,
        public loadingCtrl: LoadingController,
        public modalCtrl: ModalController,
        public navCtrl: NavController,
        public toastCtrl: ToastController,
        public user: UserService,
        public userData: UserData,
        private inAppBrowser: InAppBrowser,
        private containerService: ContainerService
    ) {
        super( user, navCtrl );
        this.searchControl = new FormControl();

    }
     openURL(url) {
        // this.inAppBrowser.create(url,'_system','location=yes');
        //this.inAppBrowser.create(url,'_self','location=yes');
        this.navCtrl.push(PdfViewerPage,{pdf:url});
    }
     
    ionViewDidLoad() {
        // this.setFilteredItems();
        this.app.setTitle( 'Containers List' );
        this.loadContainerItems();
        this.searchControl.valueChanges.debounceTime(700).subscribe(search => {
             
            
            this.searchTerm = search;
            this.setFilteredItems();
            
            
        });
    }
    loadContainerItems() {
        let loading = this.loadingCtrl.create( {
            content: `Please wait...`
        } );
        loading.present();
        this.userService.setHeaders().then(() => {
            this.userService.notificationHistory( ).subscribe(( data: any ) => {
                this.containerList = this.containerList.concat( data.data );
                this.noOfPages = data.meta.pagination.total_pages;
                this.totalItem = data.meta.pagination.total;
                loading.dismiss();
            } );
        } );
    }
    onSearchInput(){
        this.searching = true;
    }

   async setFilteredItems(){
        if(this.searchTerm != null && this.searchTerm != '')
        this.containerService.setHeaders().then(() => {
            this.containerService.searchContainer( this.searchTerm ).subscribe(( data: any ) => {
                this.containerList = data.data;
                this.searching = false;
            } );
        } );
        else{
            this.loadContainerItems();
            this.searching = false;
        }
        // this.containerList = this.containerList.filter((item)=>{
        //     console.log("ssssss",this.searchTerm);
        //     return item.container_number.toLowerCase().indexOf(this.searchTerm.toLowerCase()) > -1;
        // });
    }


    getContainerDetails( containerData: any ) {
        this.navCtrl.push( ContainerDetailPage, { containerId: containerData.id } );
    }

    loadMore() {
        this.page += 1;
        let loading = this.loadingCtrl.create( {
            content: `Please wait...`
        } );
        loading.present();
        this.userService.setHeaders().then(() => {
            this.userService.notificationHistory(this.page).subscribe(( data: any ) => {
                this.containerList = this.containerList.concat( data.data );
                this.noOfPages = data.meta.pagination.total_pages;
                loading.dismiss();
            } );
        } );
    }
    doRefresh( refresher: Refresher ) {
        this.userService.setHeaders().then(() => {
            this.userService.notificationHistory( this.page ).subscribe(( data: any ) => {
                setTimeout(() => {
                    refresher.complete();
                    this.containerList = this.containerList.concat( data.data );
                    this.noOfPages = data.meta.pagination.total_pages;
                    this.totalItem = data.meta.pagination.total;
                }, 100 );
            } );
        } );
    }
    doInfinite( infiniteScroll: any ) {
        this.page += 1;
        if ( this.page > this.noOfPages ) {
            infiniteScroll.complete();
            return false;
        }
        this.userService.setHeaders().then(() => {
            this.userService.notificationHistory( this.page ).subscribe(( data: any ) => {
                setTimeout(() => {
                    infiniteScroll.complete();
                    this.containerList = this.containerList.concat( data.data );
                    this.noOfPages = data.meta.pagination.total_pages;
                    this.totalItem = data.meta.pagination.total;
                }, 100 );
            } );
        } );

    }
    markSpecialWatch( container: any, val ) {
        if(val == 0){
            val = 1;
        }else{
            val = 0;
        }
        this.containerService.setHeaders().then(() => {
            this.containerService
                .markAsSpecialWatch( { 'container_id': container.id }, val )
                .subscribe(() => {
                    // create an alert instance
                    let alert = this.alertCtrl.create( {
                        title: 'Added as Special watch',
                        buttons: [{
                            text: 'OK',
                            handler: () => {
                                // close the sliding item
                                //                                item.close();
                            }
                        }]
                    } );
                    // now present the alert on top of all other content
                    alert.present();

                }, ( err ) => {
                    console.log( 'Mark as special error', err );
                } );
        } );
    }
    home(){
        this.navCtrl.setRoot( HomePage );
    }
    openPage(page: PageInterface) {
        let params = {};

        if (page.index) {
            params = { tabIndex: page.index };
        }
        this.navCtrl.push(page.name, params).catch((err: any) => {
            console.log(`Didn't set nav root: ${err}`);
        });
        if (page.logsOut === true) {
            // Give the menu time to close before changing to logged out
            this.userData.logout();
        }
    }
    //  backButtonAction(){
    //     /* checks if modal is open */
    //     if(this.myModal && this.myModal.index === 0) {
    //         /* closes modal */
    //         this.myModal.dismiss();
    //     } else {
    //         /* exits the app, since this is the main/first tab */
    //        // this.platform.exitApp();
    //         // this.navCtrl.setRoot(AnotherPage);  <-- if you wanted to go to another page
    //     }
    // }

setBackButtonAction() {
        this.myModal.dismiss();
    }
    openModal() {
        let obj = {filter: 'container'};
        
        this.myModal = this.modalCtrl.create(ContainerFilterPage, obj);
        this.myModal.onDidDismiss(keyword => {
            if(keyword != undefined){
                let monthNames = ["January", "February", "March", "April", "May", "June",
                        "July", "August", "September", "October", "November", "December"];
                this.keyword = keyword;
                this.keyword = this.keyword.split('&');
                let keywords="";
                for(let i=0;i<this.keyword.length;i++){
                    let kk = this.keyword[i].split("=");
                    if(kk[0] == "container_number")
                    {
                        keywords +=' / '+ "Container No. - " + kk[1];
                    }
                    if(kk[0] == "scanned_date")
                    {
                        let d = new Date(kk[1]);
                        keywords +=' / '+ "Scanned Date - " + monthNames[d.getMonth()];
                    }
                    if(kk[0] == "igm_no")
                    {
                        keywords +=' / '+ "IGM No. - " + kk[1];
                    }
                    if(kk[0] == "igm_date")
                    {
                        keywords +=' / '+ "IMG Date - " + kk[1];
                    }
                    if(kk[0] == "cfs_name")
                    {
                        keywords +=' / '+ "CFS Name - " + kk[1];
                    }
                    if(kk[0] == "date_of_examination")
                    {
                        keywords +=' / '+ "Date of Examination - " + kk[1];
                    }
                    //keywords +=' / '+this.keyword[i].replace('=', ' - ');
                }
                this.keyword = keywords;
            let loading = this.loadingCtrl.create( {
                content: `Please wait...`
            } );
            loading.present();
            this.containerService.setHeaders().then(() => {
                this.containerService.filterContainer(keyword).subscribe(( data: any ) => {
                this.containerList = data.data;
                    if ( data.meta ) {
                        this.noOfPages = data.meta.pagination.total_pages;
                        this.totalItem = data.meta.pagination.total;
                    }
                loading.dismiss();
                } );
            } );
            }
        });
       this.myModal.present();
    }
}
