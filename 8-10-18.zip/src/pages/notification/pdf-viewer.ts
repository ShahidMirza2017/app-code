import { Component } from '@angular/core';
import {
    NavController,
    NavParams
} from 'ionic-angular';
import { HomePage } from '../home/home';
import { UserService } from '../../providers/user-service';
import { BasePage } from '../base-page';
import { PageInterface } from '../../app/app.component';
import { UserData } from '../../providers/user-data';



@Component( {
    selector: 'page-pdfviewer',
    template: `<ion-header>
    <ion-navbar>
        <ion-title>
            {{title}}
        </ion-title>
        <ion-buttons end>
                <button ion-button icon-only (click)="zoomIn()">
                        <ion-icon name="add-circle"></ion-icon>
                </button>
            <button ion-button icon-only (click)="zoomOut()">
                    <ion-icon name="remove-circle"></ion-icon>
            </button>
        </ion-buttons>
    </ion-navbar>
</ion-header>
<ion-content>
<pdf-viewer [src]="pdfSrc" 
              [render-text]="true"
              [show-all]="true"
               [original-size]="false"
               [fit-to-page]="false"
               [autoresize]="true"
              [zoom]="pdfzoom"
              style="display: block;"
  ></pdf-viewer>
  </ion-content>`
} )
export class PdfViewerPage extends BasePage {
    title = 'PDF Viewer';
    pdfSrc:any;
    pdfzoom:any = 1;
   constructor(
        public navCtrl: NavController,
        public navParams: NavParams,
        public user: UserService,
        public userData: UserData,
    ) {
        super( user, navCtrl );
        this.pdfSrc = navParams.get('pdf');
    }

    zoomIn(){
        this.pdfzoom += 0.5; 
    }
    zoomOut(){
        if(this.pdfzoom > 1)
        this.pdfzoom -= 0.5;
    }

    home(){
        this.navCtrl.setRoot( HomePage );
    }
    openPage(page: PageInterface) {
        let params = {};

        if (page.index) {
            params = { tabIndex: page.index };
        }
        this.navCtrl.push(page.name, params).catch((err: any) => {
            console.log(`Didn't set nav root: ${err}`);
        });
        if (page.logsOut === true) {
            // Give the menu time to close before changing to logged out
            this.userData.logout();
        }
    }
    

}
