import { Component, ViewChild } from '@angular/core';
import {
    AlertController,
    App,
    List,
    ModalController,
    NavController,
    ToastController,
    LoadingController,
    Refresher
} from 'ionic-angular';

// import moment from 'moment';

import { UserService } from '../../providers/user-service';
import { ContainerService } from '../../providers/container.service';

//ng
import { BasePage } from '../base-page';
import { SpecialWatchDetailPage } from '../special-watch-details/special-watch-details';

@Component( {
    selector: 'page-special-watch-container',
    templateUrl: 'special-watch.html'
} )
export class SpecialWatchPage extends BasePage {
    @ViewChild( 'containerlist', { read: List } ) containerlist: List;
    title = 'Special Watches';
    dayIndex = 0;
    queryText = '';
    segment = 'all';
    excludeTracks: any = [];
    shownSessions: any = [];
    groups: any = [];
    confDate: string;

    //ng 
    containerList: any = [];
    page = 1;
    noOfPages = 0;
    constructor(
        public alertCtrl: AlertController,
        public app: App,
        public loadingCtrl: LoadingController,
        public modalCtrl: ModalController,
        public navCtrl: NavController,
        public toastCtrl: ToastController,
        public user: UserService,
        private containerService: ContainerService,
    ) {
        super( user, navCtrl );
    }

    ionViewDidLoad() {
        this.app.setTitle( 'Containers List' );
        this.loadContainerItems();
    }
    loadContainerItems() {
        let loading = this.loadingCtrl.create( {
            content: `Please wait...`
        } );
        loading.present();
        this.containerService.setHeaders().then(() => {
            this.containerService.loadSpecialWatch().subscribe(( data: any ) => {
                this.containerList = this.containerList.concat( data.data );
                if ( data.meta ) {
                    this.noOfPages = data.meta.pagination.total_pages;
                }
                loading.dismiss();
            } );
        } )
    }
    getContainerDetails( containerData: any ) {
        this.navCtrl.push( SpecialWatchDetailPage, { containerId: containerData.id } );
    }

    doRefresh( refresher: Refresher ) {
        this.containerService.setHeaders().then(() => {
            this.containerService.loadContainers().subscribe(( data: any ) => {
                setTimeout(() => {
                    refresher.complete();
                    this.containerList = this.containerList.concat( data.data );
                    if ( data.meta ) {
                        this.noOfPages = data.meta.pagination.total_pages;
                    }
                }, 100 );
            } );
        } );
    }
    doInfinite( infiniteScroll: any ) {
        this.page += 1;
        if ( this.page > this.noOfPages ) {
            infiniteScroll.complete();
            return false;
        }
        this.containerService.setHeaders().then(() => {
            this.containerService.loadContainers( this.page ).subscribe(( data: any ) => {
                setTimeout(() => {
                    infiniteScroll.complete();
                    this.containerList = this.containerList.concat( data.data );
                    if ( data.meta ) {
                        this.noOfPages = data.meta.pagination.total_pages;
                    }
                }, 100 );
            } );
        } );

    }
}
