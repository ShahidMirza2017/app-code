import { Component, OnInit } from '@angular/core';

import {
    ActionSheet,
    ActionSheetController,
    AlertController,
    MenuController,
    Config,
    NavController
} from 'ionic-angular';
import { InAppBrowser } from '@ionic-native/in-app-browser';
// Pages
import { TabsPage } from '../../pages/tabs-page/tabs-page';
import { ScannedImagesPage } from '../../pages/scanned-images/scanned-images';
import { ExaminedImagesPage } from '../../pages/examined-images/examined-images';
import { ContainerPage } from '../container/container';
import { ReportPage } from '../report/report';
import { GraphReportPage } from '../report/graph-report';
import { AddCaseRegisterPage } from '../../pages/add-case-register/add-case-register';
import { AddExaminedImagesPage } from '../../pages/add-examined-images/add-examined-images';
import { AddScannedmagesPage } from '../../pages/add-scanned-images/add-scanned-images';
import { CaseRegisterPage } from '../../pages/case-register/case-register';
import { SpecialWatchPage } from '../../pages/special-watch/special-watch';
import { CreateContainerPage } from '../../pages/container/create-container';
import { ShiftOfficerPage } from '../../pages/shift-officer/shift-officer';
import { NotificationPage } from '../../pages/notification/notification';
import { ChapterWisePage } from '../../pages/chapter-wise/chapter-wise';
import { RealTimeExaminationPage } from '../../pages/real-time/real-time-examination';
import { RealTimeScannedPage } from '../../pages/real-time/real-time-scanned';

// Interface
import { PageInterface } from '../../app/app.component';
// Services
import { UserData } from '../../providers/user-data';

// TODO remove
export interface ActionSheetButton {
    text?: string;
    role?: string;
    icon?: string;
    cssClass?: string;
    handler?: () => boolean | void;
};

@Component({
    selector: 'home',
    templateUrl: 'home.html'
})
export class HomePage implements OnInit {
    actionSheet: ActionSheet;
    speakers: any[] = [];
    cardItems: any[];
    addItems: any[];
    logOut: any;

    constructor(
        public actionSheetCtrl: ActionSheetController,
        public navCtrl: NavController,
        private alertCtrl: AlertController,
        public menu: MenuController,
        public config: Config,
        public userData: UserData,
        public inAppBrowser: InAppBrowser
    ) {
        this.logOut = { title: 'Logout', name: 'TabsPage', component: TabsPage, icon: 'log-out', logsOut: true };
        this.cardItems = [
                    //    { title: 'Scanned Images', name: 'ScannedImagesPage', component: ScannedImagesPage, icon: 'aperture' },
                    //    { title: 'Examined Images', name: 'ExaminedImagesPage', component: ExaminedImagesPage, icon: 'images' },
                    //    { title: 'Container List', name: 'ContainerPage', component: ContainerPage, icon: 'logo-dropbox' },
                    //    { title: 'Report', name: 'ReportPage', component: ReportPage, icon: 'open' },
                    //    { title: 'Case Register', name: 'CaseRegisterPage', component: CaseRegisterPage, icon: 'briefcase' },
                    //    { title: 'Shift Officer Details', name: 'ContainerPage', component: ContainerPage, icon: 'open' },
                    //    { title: 'Special Watch List', name: 'SpecialWatchPage', component: SpecialWatchPage, icon: 'open' },
                       

        ];
        this.addItems = [
        //     { title: 'Create Container', name: 'CreateContainerPage', component: CreateContainerPage, icon: 'add' },
        //     { title: 'Mark Special Watch', name: 'ContainerPage', component: ContainerPage, icon: 'logo-dropbox' },
        //     { title: 'Add Examined Images', name: 'AddExaminedImagesPage', component: AddExaminedImagesPage, icon: 'photos' },
        // //  { title: 'Add Scanned Images', name: 'AddScannedmagesPage', component: AddScannedmagesPage, icon: 'camera' },
        //     { title: 'Add Case Register', name: 'AddCaseRegisterPage', component: AddCaseRegisterPage, icon: 'briefcase' },
        ];
    } 
    ngOnInit(): void {
        this.userData.loadRoles().then((value) => {
            if (value) {
                if(value.roles[0].name == "ADMIN" || value.roles[0].name == "CFS"){
                    if(value.roles[0].name == "CFS")
                        this.menu.enable(false, 'loggedInMenu');
               // this.cardItems.push({ title: 'Case Register', name: 'CaseRegisterPage', component: CaseRegisterPage, icon: 'briefcase' });
              //  this.addItems.push({ title: 'Add Case Register', name: 'AddCaseRegisterPage', component: AddCaseRegisterPage, icon: 'briefcase' });

                for (let i = 0; i < value.roles[0].permissions.length; i++) {
                    switch (value.roles[0].permissions[i].name) {

                        case 'view-container-images':
                            this.cardItems.push({ title: 'View Scanned Images', name: 'ScannedImagesPage', component: ScannedImagesPage, icon: 'aperture' });
                            this.cardItems.push({ title: 'View Examined Images', name: 'ExaminedImagesPage', component: ExaminedImagesPage, icon: 'images' });
                            this.cardItems.push({ title: 'Image Library', name: 'ChapterWisePage', component: ChapterWisePage, icon: 'images' });
                            // this.cardItems.push({ title: 'Order Instructions', name: 'NotificationPage', component: NotificationPage, icon: 'images' });
                            break;
                        case 'view-containers':
                            this.cardItems.push({ title: 'Containers', name: 'ContainerPage', component: ContainerPage, icon: 'logo-dropbox' });
                            break;
                        case 'create-containers':
                            this.addItems.push({ title: 'Create Container', name: 'CreateContainerPage', component: CreateContainerPage, icon: 'add' });
                            break;
                    //    case 'view-graph-report':
                    //         this.cardItems.push({ title: 'Graph Reports', name: 'GraphReportPage', component: GraphReportPage, icon: 'open' });
                    //         break;
                        case 'view-daily-report':
                            this.cardItems.push({ title: 'Daily Reports', name: 'ReportPage', component: ReportPage, icon: 'open' });
                    //         this.cardItems.push({ title: 'RealTime Reports', name: 'RealTimePage', component: RealTimePage, icon: 'open' });
                            break;
                        case 'view-cases':
                            this.cardItems.push({ title: 'Case Register', name: 'CaseRegisterPage', component: CaseRegisterPage, icon: 'briefcase' });
                            break;
                        case 'view-shift-officer':
                            this.cardItems.push({ title: 'Shift Officer',name: 'ShiftOfficerPage', component: ShiftOfficerPage,  icon: 'open' });
                            break;
                        case 'view-special-watch':
                            this.cardItems.push({ title: 'Special Watch', name: 'SpecialWatchPage', component: SpecialWatchPage, icon: 'open' });
                            this.addItems.push({ title: 'Special Watch', name: 'SpecialWatchPage', component: SpecialWatchPage, icon: 'briefcase' });
                            break;
                        case 'create-cases':
                            this.addItems.push({ title: 'Add Case Register', name: 'AddCaseRegisterPage', component: AddCaseRegisterPage, icon: 'briefcase' });
                            break;
                        case 'upload-scanned-images':
                        //    this.addItems.push({ title: 'Add Scanned Images', name: 'AddScannedmagesPage', component: AddScannedmagesPage, icon: 'camera' });
                            break;
                        case 'upload-examined-images':
                            this.addItems.push({ title: 'Add Examined Images', name: 'AddExaminedImagesPage', component: AddExaminedImagesPage, icon: 'photos' });
                            break;
                        //                    case 'mark_as_special':
                        //                        pages.push( { title: 'Mark Special Watch', name: 'ContainerPage', component: ContainerPage, icon: 'open' } );
                        //                        break;
                        default:
                            // remove later
                         
                            break;
                    }
                }
                    this.cardItems.push({ title: 'Graph Reports', name: 'GraphReportPage', component: GraphReportPage, icon: 'open' });
                    this.cardItems.push({ title: 'Order Instructions', name: 'NotificationPage', component: NotificationPage, icon: 'images' });
                    this.cardItems.push({ title: 'RealTime Examination Reports', name: 'RealTimeExaminationPage', component: RealTimeExaminationPage, icon: 'open' });
                    this.cardItems.push({ title: 'RealTime Scanned Reports', name: 'RealTimeScannedPage', component: RealTimeExaminationPage, icon: 'open' });
                
            }else{
                let alert = this.alertCtrl.create({
                title: 'Unauthorized',
                subTitle: 'You Have Not Permission',
                buttons: ['Dismiss']
            });
            alert.present();
                this.userData.logout();
            }
            }

        });
    }
    openPage(page: PageInterface) {
        let params = {};

        if (page.index) {
            params = { tabIndex: page.index };
        }
        this.navCtrl.push(page.name, params).catch((err: any) => {
            console.log(`Didn't set nav root: ${err}`);
        });
        if (page.logsOut === true) {
            // Give the menu time to close before changing to logged out
            this.userData.logout();
        }
    }
}
