import { Component } from '@angular/core';
import { NavParams } from 'ionic-angular';

import { ContainerService } from '../../providers/container.service';

@Component({
  selector: 'page-container-detail',
  templateUrl: 'container-detail.html'
})
export class ContainerDetailPage {
  session: any;
  cDetails: any;
  constructor(
    public containerService: ContainerService,
    public navParams: NavParams
  ) { }

  ionViewWillEnter() {
    this.containerService.getContainerDetails(this.navParams.data.containerId)
      .subscribe((data: any) => {
        this.cDetails = data.data;
        console.log(JSON.stringify("Container Details:::"+this.cDetails.scannedImage.data.image))
        console.log(this.cDetails);
      });
  }
}
