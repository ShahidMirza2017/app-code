import { Component, OnInit } from '@angular/core';
import {
    NavController,
    NavParams,
    ViewController,
    ActionSheetController,
    ToastController,
    Platform,
    LoadingController,
    Loading
} from 'ionic-angular';
import { ContainerService } from '../../providers/container.service';
import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms'


@Component( {
    selector: 'page-container-filter',
    templateUrl: 'container-filter.html'
} )
export class ContainerFilterPage implements OnInit {
  filter: string = this.navParams.get('filter');  
  title = 'Filter '+this.filter;
  formData: FormGroup;
    _co:any; 
    keyword: any = "";
    

    igm_no: boolean = false;
    igm_date: boolean = false;
    cfs_name: boolean = false;
    scanned_date: boolean = false;
    scanned_month: boolean = false;
    date_of_examination: boolean = false;
    shift: boolean = false;
    scanning_result: boolean = false; 
has_examined_images: boolean =false;
has_scanned_images: boolean =false;
    // image
    lastImage: string = null;
    loading: Loading;
    chapterheadings: any;
    container_img: any;
    constructor(
        public containerService: ContainerService,
        private fb: FormBuilder,
        public navCtrl: NavController,
        public navParams: NavParams,
        public viewCtrl: ViewController,
        public actionSheetCtrl: ActionSheetController,
        public toastCtrl: ToastController,
        public platform: Platform,
        public loadingCtrl: LoadingController,
    
    ) {
      this.viewCtrl = viewCtrl;
        this.formData = this.fb.group( {
            igm_no: new FormControl( '', Validators.required ),
            container_number: new FormControl( '', Validators.required ),
            container_id: new FormControl( '', Validators.required ),
            igm_date: new FormControl( '', Validators.required ),
            cfs_name: new FormControl( '', Validators.required ),
            date_of_examination: new FormControl( '', Validators.required ),
            scanned_date: new FormControl( '', Validators.required ),
            scanned_month: new FormControl( '', Validators.required ),
            shift: new FormControl( '', Validators.required ),
            scanning_result: new FormControl( '', Validators.required ),
            has_examined_images: new FormControl( '', Validators.required ),
            has_scanned_images: new FormControl( '', Validators.required ),

        } );

this.formData.get( 'has_examined_images' ).setValue(false);
this.formData.get( 'has_scanned_images' ).setValue(false);
    }
    ngOnInit() {
      if(this.filter == "container"){
          this.igm_no = true;
          this.igm_date = true;
          this.cfs_name = true;
          this.scanned_date = true;
          this.scanned_month = true;
          this.date_of_examination = true;
	  this.scanning_result = true;
	 this.has_examined_images = true;
	 this.has_scanned_images = true;

      }else if(this.filter == "scanned"){
          this.scanned_date = true;
          this.scanned_month = true;
          this.shift = true;
      }else if(this.filter == "examined"){
          this.shift = true;
          this.scanned_date = true;
          this.scanned_month = true;
          this.date_of_examination = true;
      }
    }
    onSelected( item: any ) {
        this.formData.get( 'container_number' ).setValue( item['container_number'] ); 
        this.formData.get('container_id').setValue(item['id']);
        // this.container_img = item.scannedImage.data.image;
        // this.userData.getUserId().then(( id ) => {
        //     this.formData.get( 'user_id' ).setValue( id );
        // } );
    }
    onSelected1( item: any ) {
        this.formData.get( 'cfs_name' ).setValue( item['cfs_name'] ); 
    }
    submit() {
      this.keyword="";
      if(this.formData.get( 'igm_no' ).value != "")
        this.keyword+="igm_number="+this.formData.get( 'igm_no' ).value+"&";
    //   if(this.formData.get( 'container_number' ).value != "") 
    //     this.keyword+="container_number="+this.formData.get( 'container_number' ).value+"&";
      if(this.formData.get( 'container_id' ).value != "") 
        this.keyword+="container_id="+this.formData.get( 'container_id' ).value+"&";
      if(this.formData.get( 'igm_date' ).value != "")
        this.keyword+="igm_date="+this.formData.get( 'igm_date' ).value+"&";
      if(this.formData.get( 'cfs_name' ).value != "")
        this.keyword+="cfs_name="+this.formData.get( 'cfs_name' ).value+"&";
      if(this.formData.get( 'date_of_examination' ).value != "")
        this.keyword+="date_of_examination="+this.formData.get( 'date_of_examination' ).value+"&";
      if(this.formData.get( 'scanned_date' ).value != "")
        this.keyword+="scanned_date="+this.formData.get( 'scanned_date' ).value+"&";
      if(this.formData.get( 'scanned_month' ).value != "")
        this.keyword+="scanned_month="+this.formData.get( 'scanned_month' ).value+"&";
      if(this.formData.get( 'shift' ).value != "")
        this.keyword+="shift="+this.formData.get( 'shift' ).value+"&";
      if(this.formData.get( 'scanning_result' ).value != "")
        this.keyword+="scanning_result="+this.formData.get( 'scanning_result' ).value+"&";
      if(this.formData.get( 'has_examined_images' ).value != ""){
            let eival = 0;
            if(this.formData.get( 'has_examined_images' ).value == true)
                eival = 1;
            else
                eival = 0;	
            this.keyword+="has_examined_images="+eival+"&";
        }
      if(this.formData.get( 'has_scanned_images' ).value != ""){
            let sival = 0;
            if(this.formData.get( 'has_scanned_images' ).value == true)
                sival = 1;
            else
                sival = 0;	
            this.keyword+="has_scanned_images="+sival+"&";
      }
 
     console.log(this.keyword);
      this.viewCtrl.dismiss(this.keyword);
      
        // if ( this.formData.valid ) {
        //   //  this.uploadDataAndImages( this.formData.value );
        // } else {
        //     Object.keys( this.formData.controls ).forEach( field => { // {1}
        //         const control = this.formData.get( field );            // {2}
        //         control.markAsTouched( { onlySelf: true } );       // {3}
        //     } );
        // }
    }
  
    isValid( key, validation = 'required' ) {
        return this.formData.get( key ).hasError( validation ) &&
            ( this.formData.get( key ).dirty ||
                this.formData.get( key ).touched )
    }
  
    ionViewDidLoad() {
        // this.setFilteredItems();
        this.loadChapterHeading();     
    }
    loadChapterHeading() {
        let loading = this.loadingCtrl.create( {
            content: `Please wait...`
        } );
        loading.present();
        this.containerService.setHeaders().then(() => {
            this.containerService.loadChapterheading().subscribe(( data: any ) => {
                //console.log(data.data);
                this.chapterheadings = data.data;
                //   this.noOfPages = data.meta.pagination.total_pages;
                //  this.totalItem = data.meta.pagination.total;
                loading.dismiss();
            } );
        } );
    }
// _co.dismiss(){
//   this.viewCtrl.dismiss();
// }
backButtonAction(){
        this.viewCtrl.dismiss();
    }
    setBackButtonAction() {
        this.viewCtrl.dismiss();
    }
      closeModal() {
    this.viewCtrl.dismiss();
  }
}
