import { Component } from '@angular/core';
import { NavParams } from 'ionic-angular';

import { CaseRegisterService } from '../../providers/case-register.service';

@Component( {
    selector: 'page-case-register-detail',
    templateUrl: 'case-register-detail.html'
} )
export class CaseRegisterDetailPage {
    session: any;
    cDetails: any;
    title: string;
    constructor(
        public caseRegisterService: CaseRegisterService,
        public navParams: NavParams
    ) { }

    ionViewWillEnter() {
        this.title = `Case # ${ this.navParams.data.caseId }  Details`;
        this.caseRegisterService.setHeaders().then(() => {
            this.caseRegisterService.getCaseDetails( this.navParams.data.caseId )
                .subscribe(( data: any ) => {
                    this.cDetails = data.data;
                } );
        } );
    }
}
