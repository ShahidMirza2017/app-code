import { Component, OnInit } from '@angular/core';
import {
    NavController,
    ToastController,
    Platform,
    LoadingController,
    App,
    Refresher
} from 'ionic-angular';
import { ContainerService } from '../../providers/container.service';
import { CaseRegisterService } from '../../providers/case-register.service';
import { UserService } from '../../providers/user-service';
import { CaseRegisterDetailPage } from '../case-register-detail/case-register-detail';
import { BasePage } from '../base-page';


@Component( {
    selector: 'page-case-register',
    templateUrl: 'case-register.html'
} )
export class CaseRegisterPage extends BasePage implements OnInit {
    title = 'Case Register';
    casesList: any = [];
    page = 1;
    noOfPages = 0;
    constructor(
        public containerService: ContainerService,
        public caseRegisterService: CaseRegisterService,
        public app: App,
        public navCtrl: NavController,
        public toastCtrl: ToastController,
        public platform: Platform,
        public loadingCtrl: LoadingController,
        public user: UserService,
    ) {
        super( user, navCtrl );
    }
    ngOnInit() {
        this.loadCasesItems();
    }

    ionViewDidLoad() {
        this.app.setTitle( 'Cases List' );

    }
    loadCasesItems() {
        let loading = this.loadingCtrl.create( {
            content: `Please wait...`
        } );
        loading.present();
        this.caseRegisterService.setHeaders().then(() => {
            this.caseRegisterService.loadCases().subscribe(( data: { data: any[] } ) => {
                this.casesList = this.casesList.concat( data.data );
                loading.dismiss();
            } );
        } );
    }

    getCaseDetails( caseData: any ) {
        this.navCtrl.push( CaseRegisterDetailPage, { caseId: caseData.id } );
    }
    doRefresh( refresher: Refresher ) {
        this.caseRegisterService.setHeaders().then(() => {
            this.caseRegisterService.loadCases()
                .subscribe(( data: { data: any } ) => {
                    setTimeout(() => {
                        refresher.complete();
                        this.casesList = data.data ;
                    }, 100 );
                } );
        } );
    }
    doInfinite( infiniteScroll: any ) {
        this.page += 1;
        if ( this.page > this.noOfPages ) {
            infiniteScroll.complete();
            return false;
        }
        this.caseRegisterService.setHeaders().then(() => {
            this.caseRegisterService.loadCases( this.page )
                .subscribe(( data: any ) => {
                    setTimeout(() => {
                        infiniteScroll.complete();
                        this.casesList = data.data;
                        this.casesList = this.casesList.concat( data.data );
                        if ( data.meta ) {
                            this.noOfPages = data.meta.pagination.total_pages;
                        }

                    }, 100 );
                } );
        } );
    }

}
