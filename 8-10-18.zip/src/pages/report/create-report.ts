
import { Component, OnInit } from '@angular/core';
import {
    NavController,
    ToastController,
    LoadingController,
    Loading
} from 'ionic-angular';
import { ReportService } from '../../providers/report.service';
import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms'
import { ReportPage } from '../report/report';

@Component( {
    selector: 'page-create-report',
    templateUrl: 'create-report.html'
} )
export class CreateReportPage implements OnInit {
    title = 'Create Report';
    formData: FormGroup;
    loading: Loading;
    constructor(
        public reportService: ReportService,
        private fb: FormBuilder,
        public navCtrl: NavController,
        public toastCtrl: ToastController,
        public loadingCtrl: LoadingController
    ) {
        this.formData = this.fb.group( {
            date: new FormControl( '', Validators.required ),
            fsd_mismatch: new FormControl( '', Validators.required ),
            fsd_total: new FormControl( '', Validators.required ),
            msd_mismatch: new FormControl( '', Validators.required ),
            msd_total: new FormControl( '', Validators.required ),
            not_scanned_empty: new FormControl( '', Validators.required ),
            not_scanned_owt: new FormControl( '', Validators.required ),
            shift: new FormControl( '', Validators.required ),
            total_scanned: new FormControl( '', Validators.required ),
            user_id: new FormControl( '', Validators.required ),
        } );
    }
    ngOnInit() {
        this.formData.get( 'user_id' ).setValue( 1 );
    }
    submit() {
        if ( this.formData.valid ) {
            let loading = this.loadingCtrl.create( {
                content: `Please wait...`
            } );
            loading.present();
            this.reportService.setHeaders().then(() => {
                this.reportService.createReport( this.formData.value )
                    .subscribe(() => {
                        loading.dismiss();

                        this.showToast( 'Created successfully.' );
                        this.navCtrl.push( ReportPage );

                    }, ( er: any ) => {
                        loading.dismiss();
                        this.showToast( 'Something went wrong.' + er.error );
                    } );
            } );
        } else {
            Object.keys( this.formData.controls ).forEach( field => { // {1}
                const control = this.formData.get( field );            // {2}
                control.markAsTouched( { onlySelf: true } );       // {3}
            } );
        }
    }

    private showToast( msg ) {
        let toast = this.toastCtrl.create( {
            message: msg,
            duration: 3000,
            position: 'bottom'
        } );
        toast.present();
    }
    setBackButtonAction() {
        this.navCtrl.setRoot( ReportPage );
    }
}
