import { Component } from '@angular/core';
import {
    AlertController,
    App,
    ModalController,
    NavController,
    ToastController,
    LoadingController
} from 'ionic-angular';
import { DatePipe } from '@angular/common'

//import { FormControl } from '@angular/forms';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/switchMap';
// import { Chart } from 'chart.js';

import { HomePage } from '../home/home';

// import moment from 'moment';

import { UserService } from '../../providers/user-service';
import { ReportService } from '../../providers/report.service';

//ng
import { BasePage } from '../base-page';
import { PageInterface } from '../../app/app.component';
import { UserData } from '../../providers/user-data';

import { CreateReportPage } from '../report/create-report';

@Component( {
    selector: 'page-report',
    templateUrl: 'report.html'
} )
export class ReportPage extends BasePage {
   
    title = 'Daily Reports';
    dailyreport: any = [];
    odailyreport: any = [];
    graphData: any;
    reportDate:any = new Date();


    constructor(
        public alertCtrl: AlertController,
        public app: App,
        public loadingCtrl: LoadingController,
        public modalCtrl: ModalController,
        public navCtrl: NavController,
        public toastCtrl: ToastController,
        public user: UserService,
        public userData: UserData,
        private reportService: ReportService,
        public datepipe: DatePipe
    ) {
        super( user, navCtrl );
        
    this.reportDate = this.datepipe.transform(this.reportDate, 'yyyy-MM-dd');
    }

    public barChartOptions:any = {
        scaleShowVerticalLines: false,
        responsive: true
      };
    //   public barChartLabels:string[] = ['2006', '2007', '2008', '2009', '2010', '2011', '2012'];
     
      public barChartType:string = 'bar';
      public barChartLegend:boolean = true;
      public barChartLabels:any[] = [];
      public barChartData:any[] = [{data:[],label:''}];
      public barChartLabels1:any[] = [];
      public barChartData1:any[] = [{data:[],label:''}];
      public barChartLabels2:any[] = [];
      public barChartData2:any[] = [{data:[],label:''}];
      public barChartLabels3:any[] = [];
      public barChartData3:any[] = [{data:[],label:''}];
      public barChartLabels4:any[] = [];
      public barChartData4:any[] = [{data:[],label:''}];
      // events
      public chartClicked(e:any):void {
        console.log(e);
      }
      
      public chartHovered(e:any):void {
        console.log(e);
      }

    ionViewDidLoad() {
        this.app.setTitle( 'Daily Reports' );
        this.loadDailyReport();
       // this.loadGraph();
        
    }
    loadDailyReport() {
        let loading = this.loadingCtrl.create( {
            content: `Please wait...`
        } );
        loading.present();
        this.reportService.setHeaders().then(() => {
        this.reportService.loadReport().subscribe((data: any)=>{
         this.odailyreport = data.data;
        this.dailyreport = data.data;
        this.changeDate(this.reportDate);
        //console.log(this.reportDate);
        loading.dismiss();
        });
    });
    }

    changeDate(reportDate){
        this.dailyreport = this.odailyreport.filter((item) => {
            return item.date.indexOf(reportDate.toString()) > -1;
        }); 
    }
   
    home(){
        this.navCtrl.setRoot( HomePage );
    }
    addReport(){
        this.openPage({ title: 'Create Daily Report', name: 'CreateReportPage', component: CreateReportPage, icon: 'add' });
    }
    openPage(page: PageInterface) {
        let params = {};

        if (page.index) {
            params = { tabIndex: page.index };
        }
        this.navCtrl.push(page.name, params).catch((err: any) => {
            console.log(`Didn't set nav root: ${err}`);
        });
        if (page.logsOut === true) {
            // Give the menu time to close before changing to logged out
            this.userData.logout();
        }
    }
}
