import { Component } from '@angular/core';
import {
    AlertController,
    App,
    ModalController,
    NavController,
    ToastController,
    LoadingController
} from 'ionic-angular';
import { DatePipe } from '@angular/common'

//import { FormControl } from '@angular/forms';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/switchMap';
// import { Chart } from 'chart.js';

import { HomePage } from '../home/home';

// import moment from 'moment';

import { UserService } from '../../providers/user-service';
import { ReportService } from '../../providers/report.service';

//ng
import { BasePage } from '../base-page';
import { PageInterface } from '../../app/app.component';
import { UserData } from '../../providers/user-data';

import { CreateReportPage } from '../report/create-report';

@Component( {
    selector: 'page-graph-report',
    templateUrl: 'graph-report.html'
} )
export class GraphReportPage extends BasePage {
   
    title = 'Graph Reports';
    dailyreport: any = [];
    odailyreport: any = [];
    graphData: any;
    reportDate:any = new Date();
    curYear:any = new Date();


    constructor(
        public alertCtrl: AlertController,
        public app: App,
        public loadingCtrl: LoadingController,
        public modalCtrl: ModalController,
        public navCtrl: NavController,
        public toastCtrl: ToastController,
        public user: UserService,
        public userData: UserData,
        private reportService: ReportService,
        public datepipe: DatePipe
    ) {
        super( user, navCtrl );
        
    this.reportDate = this.datepipe.transform(this.reportDate, 'yyyy-MM-dd');
    this.curYear = this.datepipe.transform(this.curYear, 'yyyy');
    
    }

    public barChartOptions:any = {
        scaleShowVerticalLines: false,
        responsive: true
      };
    //   public barChartLabels:string[] = ['2006', '2007', '2008', '2009', '2010', '2011', '2012'];
     
      public barChartType:string = 'bar';
      public barChartType1:string = 'line';
      public barChartLegend:boolean = true;
      public barChartLabels:any[] = [];
      public barChartData:any[] = [{data:[],label:''},{data:[],label:''},{data:[],label:''}];
      public barChartLabels1:any[] = [];
      public barChartData1:any[] = [{data:[],label:''},{data:[],label:''},{data:[],label:''}];
      public barChartLabels2:any[] = [];
      public barChartData2:any[] = [{data:[],label:''},{data:[],label:''},{data:[],label:''}];
      public barChartLabels3:any[] = [];
      public barChartData3:any[] = [{data:[],label:''}];
      public barChartLabels4:any[] = [];
      public barChartData4:any[] = [{data:[],label:''},{data:[],label:''},{data:[],label:''},{data:[],label:''},{data:[],label:''}];
      // events
      public chartClicked(e:any):void {
        console.log(e);
      }
      
      public chartHovered(e:any):void {
        console.log(e);
      }

    ionViewDidLoad() {
        this.app.setTitle( 'Graph Reports' );
        this.loadGraph();
        
    }
    
    changeDate(reportDate){
        this.dailyreport = this.odailyreport.filter((item) => {
            return item.date.indexOf(reportDate.toString()) > -1;
        }); 
    }
   
    loadGraph() {
        let loading = this.loadingCtrl.create( {
            content: `Please wait...`
        } );
        loading.present();
        this.reportService.setHeaders().then(() => {
        this.reportService.loadGraph().subscribe((data: any)=>{
            console.log("report",data);
        this.graphData = data;
        this.tot(data);
        this.scannedContainersFixed(data);
        this.scannedMobileFixed(data);
        //this.clean(data);
        this.mismatch(data);
        //this.barChartData.push({data: this.totData,label:"Total"});
        
        loading.dismiss();
        });
    this.reportService.loadGraphMisMatch().subscribe((data: any)=>{
        this.clean(data);
        });
    });
    }

    tot(data){
        let tot = JSON.parse(data.total);
        let totData = [];
        let fsd = [];
        let msd = [];
        for(let i=0;i<tot.length;i++){
            this.barChartLabels.push(tot[i].month_name);
            totData.push(tot[i].total_number);
        }
        let fsdc =JSON.parse(data.fixedPerformanceClean);
        let fsdm =JSON.parse(data.fixedPerformanceMismatch);
        for(let i=0;i<fsdc.length;i++){
            fsd.push(fsdc[i].total_number+fsdm[i].total_number);
        }
        let msdc =JSON.parse(data.mobilePerformanceClean);
        let msdm =JSON.parse(data.mobilePerformanceMismatch);
        for(let i=0;i<msdc.length;i++){
            msd.push(msdc[i].total_number+msdm[i].total_number);
        }
        console.log(totData);
        let clone = JSON.parse(JSON.stringify(this.barChartData));
        clone[0].data = totData;
        clone[0].label = "Total Scanning";
        clone[1].data = fsd;
        clone[1].label = "FSD";
        clone[2].data = msd;
        clone[2].label = "MSD";
        this.barChartData = clone;
    }
    scannedContainersFixed(data){
        let tot = JSON.parse(data.fixedPerformance);
        let totData = [];
        for(let i=0;i<tot.length;i++){
            this.barChartLabels1.push(tot[i].month_name);
            totData.push(tot[i].total_number);
        }
        let tot1 = JSON.parse(data.fixedPerformanceMismatch);
        let totData1 = [];
        for(let i=0;i<tot1.length;i++){
            totData1.push(tot1[i].total_number);
        }
        let tot2 = JSON.parse(data.fixedPerformanceClean);
        let totData2 = [];
        for(let i=0;i<tot2.length;i++){
            totData2.push(tot2[i].total_number);
        }
        console.log(totData);
        let clone = JSON.parse(JSON.stringify(this.barChartData1));
        clone[0].data = totData;
        clone[0].label = "Total Fixed Scanner Data";
        clone[1].data = totData1;
        clone[1].label = "Total Fixed Scanner Mismatch";
        clone[2].data = totData2;
        clone[2].label = "Total Fixed Scanner Clean";
        this.barChartData1 = clone;
    }
    scannedMobileFixed(data){
        let tot = JSON.parse(data.mobilePerformance);
        let totData = [];
        for(let i=0;i<tot.length;i++){
            this.barChartLabels2.push(tot[i].month_name);
            totData.push(tot[i].total_number);
        }
        let tot1 = JSON.parse(data.mobilePerformanceMismatch);
        let totData1 = [];
        for(let i=0;i<tot1.length;i++){
            totData1.push(tot1[i].total_number);
        }
        let tot2 = JSON.parse(data.mobilePerformanceClean);
        let totData2 = [];
        for(let i=0;i<tot2.length;i++){
            totData2.push(tot2[i].total_number);
        }
        console.log(totData);
        let clone = JSON.parse(JSON.stringify(this.barChartData2));
        clone[0].data = totData;
        clone[0].label = "Total Mobile Scanner Data";
        clone[1].data = totData1;
        clone[1].label = "Total Mobile Scanner Mismatch";
        clone[2].data = totData2;
        clone[2].label = "Total Mobile Scanner Clean";
        this.barChartData2 = clone;
    }
        scannedContainersFixedMismatch(data){
        let tot = JSON.parse(data.scannedContainersFixedMismatch);
        let totData = [];
        for(let i=0;i<tot.length;i++){
            this.barChartLabels2.push(tot[i].month_name);
            totData.push(tot[i].total_number);
        }
        console.log(totData);
        let clone = JSON.parse(JSON.stringify(this.barChartData2));
        clone[0].data = totData;
        clone[0].label = "Total";
        this.barChartData2 = clone;
    }
     clean(data){
        let tot = JSON.parse(data.total);
        let totData = [];
        let tot1 = JSON.parse(data.mismatch);
        let totData1 = [];
        for(let i=0;i<tot.length;i++){
            this.barChartLabels3.push(tot[i].month_name);
            totData.push((tot1[i].total_mismatch_number/tot[i].total_number)*100);
console.log(tot1[i].total_number );
        }
        console.log(totData);
        console.log(tot);
        console.log(tot1);
        let clone = JSON.parse(JSON.stringify(this.barChartData3));
        clone[0].data = totData;
        clone[0].label = "Mismatch Percentage";
        this.barChartData3 = clone;
    }
     mismatch(data){
        let tot = JSON.parse(data.scannedContainersFixed);
        let totData = [];
        for(let i=0;i<tot.length;i++){
            this.barChartLabels4.push(tot[i].month_name);
            totData.push(tot[i].total_number);
        }
        let tot1 = JSON.parse(data.fixedCases);
        let totData1 = [];
        for(let i=0;i<tot1.length;i++){
            totData1.push(tot1[i].total_number);
        }
        let tot2 = JSON.parse(data.mobilePerformanceMismatch);
        let totData2 = [];
        for(let i=0;i<tot2.length;i++){
            totData2.push(tot2[i].total_number);
        }
        let tot3 = JSON.parse(data.mobileCases);
        let totData3 = [];
        for(let i=0;i<tot3.length;i++){
            totData3.push(tot3[i].total_number);
        }
        console.log(totData);
        let clone = JSON.parse(JSON.stringify(this.barChartData4));
        clone[0].data = totData;
        clone[0].label = "Fixed MisMatches";
        clone[1].data = totData1;
        clone[1].label = "Fixed Cases";
        clone[2].data = totData2;
        clone[2].label = "Mobile MisMatches";
        clone[3].data = totData3;
        clone[3].label = "Mobile Cases";
        this.barChartData4 = clone;
    }
   
    home(){
        this.navCtrl.setRoot( HomePage );
    }
    addReport(){
        this.openPage({ title: 'Create Daily Report', name: 'CreateReportPage', component: CreateReportPage, icon: 'add' });
    }
    openPage(page: PageInterface) {
        let params = {};

        if (page.index) {
            params = { tabIndex: page.index };
        }
        this.navCtrl.push(page.name, params).catch((err: any) => {
            console.log(`Didn't set nav root: ${err}`);
        });
        if (page.logsOut === true) {
            // Give the menu time to close before changing to logged out
            this.userData.logout();
        }
    }
}
