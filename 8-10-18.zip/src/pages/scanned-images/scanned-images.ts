import { Component } from '@angular/core';
import {
    NavController,
    LoadingController,
    ModalController,
    Refresher
} from 'ionic-angular';
import { FormControl } from '@angular/forms';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/switchMap';

import { ContainerService } from '../../providers/container.service';
import { UserService } from '../../providers/user-service';
import { HomePage } from '../home/home';

import { BasePage } from '../base-page';
import { PageInterface } from '../../app/app.component';
import { UserData } from '../../providers/user-data';

import { ContainerFilterPage } from '../container-filter/container-filter';

@Component( {
    selector: 'page-scanned-images',
    templateUrl: 'scanned-images.html'
} )
export class ScannedImagesPage extends BasePage{
    session: any;
    cDetails: any;
    page = 1;
    noOfPages = 0;
    totalItem = 0;
    keyword:any;
    searching: any = false;
    searchTerm: string = '';
    searchControl: FormControl;

    isFilter=0;
    paramKeys:any;

    constructor(
        public containerService: ContainerService,
        private navController: NavController,
        public loadingCtrl: LoadingController,
        public modalCtrl: ModalController,
        public user: UserService,
        public userData: UserData,
    ) {
        super( user, navController );
        this.cDetails = [];
    }

    ionViewWillEnter() {
        let loading = this.loadingCtrl.create( {
            content: `Please wait...`
        } );
        loading.present();
        this.containerService.setHeaders().then(() => {
            this.containerService.getScannedImages()
                .subscribe(( data: any ) => {
                    this.cDetails = this.cDetails.concat( data.data );
                    if ( data.meta ) {
                        this.noOfPages = data.meta.pagination.total_pages;
                        this.totalItem = data.meta.pagination.total;
                    }
                    loading.dismiss();
                } );
        } );
            // this.searchControl.valueChanges.debounceTime(700).subscribe(search => {
            //     this.searchTerm = search;
            //     this.setFilteredItems();
            // });
    }
    doRefresh( refresher: Refresher ) {
        this.containerService.setHeaders().then(() => {
            this.containerService.getScannedImages()
                .subscribe(( data: any ) => {
                    this.cDetails = this.cDetails.concat( data.data );
                    if ( data.meta ) {
                        this.noOfPages = data.meta.pagination.total_pages;
                        this.totalItem = data.meta.pagination.total;
                    }
                    refresher.complete();
                } );
        } );
    }
    doInfinite( infiniteScroll: any ) {
        this.page += 1;
        if(this.isFilter == 1){
            let keys = this.paramKeys;
            keys +="page="+this.page;
            this.containerService.setHeaders().then(() => {
                this.containerService.getScannedImages(keys).subscribe(( data: any ) => {
                 setTimeout(() => {
                        infiniteScroll.complete();
                    this.cDetails = this.cDetails.concat(data.data);
                    if ( data.meta ) {
                        this.noOfPages = data.meta.pagination.total_pages;
                        this.totalItem = data.meta.pagination.total;
                    }
                    }, 100 );
                } );
            } );
        }else{
        this.containerService.setHeaders().then(() => {
            this.containerService.getScannedImages( this.page ).subscribe(( data: any ) => {
                setTimeout(() => {
                    infiniteScroll.complete();
                    this.cDetails = this.cDetails.concat( data.data );
                    if ( data.meta ) {
                        this.noOfPages = data.meta.pagination.total_pages;
                        this.totalItem = data.meta.pagination.total;
                    }
                }, 100 );
            } );
        } );
        }
    }
    // setBackButtonAction() {
    //     this.navController.setRoot( HomePage );
    // }
    home(){
        this.navController.setRoot( HomePage );
    }
    openPage(page: PageInterface) {
        let params = {};

        if (page.index) {
            params = { tabIndex: page.index };
        }
        this.navController.push(page.name, params).catch((err: any) => {
            console.log(`Didn't set nav root: ${err}`);
        });
        if (page.logsOut === true) {
            // Give the menu time to close before changing to logged out
            this.userData.logout();
        }
    }

     onSearchInput(){
        this.searching = true;
    }

   async setFilteredItems(){
        if(this.searchTerm != null && this.searchTerm != '')
        this.containerService.setHeaders().then(() => {
            this.containerService.searchContainer( this.searchTerm ).subscribe(( data: any ) => {
                console.log(data);
             //   this.containerList = data.data;
                this.searching = false;
            } );
        } );
        else{
          //  this.loadContainerItems();
            this.searching = false;
        }
        // this.containerList = this.containerList.filter((item)=>{
        //     console.log("ssssss",this.searchTerm);
        //     return item.container_number.toLowerCase().indexOf(this.searchTerm.toLowerCase()) > -1;
        // });
    }
openModal() {
    let obj = {filter: 'scanned'};
        this.page = 1;
        this.isFilter = 1;
        let myModal = this.modalCtrl.create(ContainerFilterPage,obj);
        myModal.onDidDismiss(keyword => {
            if(keyword != undefined){
                 let monthNames = ["January", "February", "March", "April", "May", "June",
                        "July", "August", "September", "October", "November", "December"];
                this.keyword = keyword;
                this.paramKeys = keyword;
                this.keyword = this.keyword.split('&');
                let keywords="";
                for(let i=0;i<this.keyword.length;i++){
                    let kk = this.keyword[i].split("=");
                    if(kk[0] == "container_number")
                    {
                        keywords +=' / '+ "Container No. - " + kk[1];
                    }
                    if(kk[0] == "scanned_date")
                    {
                        let d = new Date(kk[1]);
                        keywords +=' / '+ "Scanned Date - " + monthNames[d.getMonth()];
                    }
                    if(kk[0] == "shift")
                    {
                        keywords +=' / '+ "Shift - " + kk[1];
                    }
                }
                this.keyword = keywords;
                let loading = this.loadingCtrl.create( {
                content: `Please wait...`
            } );
            loading.present();
            this.containerService.setHeaders().then(() => {
                this.containerService.filterScanned(keyword).subscribe(( data: any ) => {
                this.cDetails = data.data;
                    if ( data.meta ) {
                        this.noOfPages = data.meta.pagination.total_pages;
                        this.totalItem = data.meta.pagination.total;
                    }
                loading.dismiss();
                } );
            } );
            
            }
        });
        myModal.present();
    }
}
