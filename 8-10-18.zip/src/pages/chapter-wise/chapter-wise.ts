import { Component } from '@angular/core';
import {
    NavController, Refresher,
    LoadingController,
    ModalController
} from 'ionic-angular';

import { FormControl } from '@angular/forms';
import 'rxjs/add/operator/debounceTime';

import { HomePage } from '../home/home';
import { ContainerService } from '../../providers/container.service';
import { UserService } from '../../providers/user-service';
import { BasePage } from '../base-page';
import { PageInterface } from '../../app/app.component';
import { UserData } from '../../providers/user-data';
import { ContainerFilterPage } from '../container-filter/container-filter';

import { ChapterWiseDetailPage } from '../chapter-wise-detail/chapter-wise-detail';

@Component( {
    selector: 'page-chapter-wise',
    templateUrl: 'chapter-wise.html'
} )
export class ChapterWisePage extends BasePage {
    session: any;
    cDetails: any;
    chDetails: any;
    ochDetails: any;
    page = 1;
    noOfPages = 0;
    totalItem = 0;
    keyword:any;
    title:any = "Chapterwise Image Library";
    filterItemsamedata:any = [];

    chapterHeading: any = false;

    searchTerm: string = '';
    searchControl: FormControl;
    searching: any = false;

    constructor(
        public containerService: ContainerService,
        private navCtrl: NavController,
        public loadingCtrl: LoadingController,
        public modalCtrl: ModalController,
        public user: UserService,
        public userData: UserData,
    ) {
        super(user,navCtrl);
        this.cDetails = [];
        this.chDetails = [];
        this.ochDetails = [];
        this.searchControl = new FormControl();
    }

    ionViewDidLoad() {
        this.setFilteredItems("");
        this.searchControl.valueChanges.debounceTime(700).subscribe(search => {
            this.searching = false;
            this.setFilteredItems(search);
        });
 
 
    }
 
    onSearchInput(){
        this.searching = true;
    }
 
    setFilteredItems(search) {
        if(search == "" || search == null)
            this.chDetails = this.ochDetails;
        else
        this.chDetails =  this.ochDetails.filter((item) => {
            return item.name.toLowerCase().indexOf(search.toLowerCase()) > -1;
        });    
    }

    ionViewWillEnter() {
        
        let loading = this.loadingCtrl.create( {
            content: `Please wait...`
        } );
        loading.present();
        this.containerService.setHeaders().then(() => {
             this.containerService.loadChapterheading().subscribe(( data: any ) => {
                console.log(data.data);
                this.chDetails = data.data;
                this.ochDetails = data.data;
                loading.dismiss();
            } );
        } );
        
    }
    setBackButtonAction() {
        this.navCtrl.push( HomePage );
    }
    doRefresh( refresher: Refresher ) {
        this.containerService.setHeaders().then(() => {
            this.containerService.getImageLibrary()
                .subscribe(( data: any ) => {
                    this.cDetails = this.cDetails.concat( data.data );
                    if ( data.meta ) {
                        this.noOfPages = data.meta.pagination.total_pages;
                        this.totalItem = data.meta.pagination.total;
                    }
                    refresher.complete();
                } );
        } );
    }
    doInfinite( infiniteScroll: any ) {
        this.page += 1;
        this.containerService.setHeaders().then(() => {
            this.containerService.getImageLibrary( this.page )
                .subscribe(( data: any ) => {
                    setTimeout(() => {
                        infiniteScroll.complete();
                        this.cDetails = this.cDetails.concat( data.data );
                        if ( data.meta ) {
                            this.noOfPages = data.meta.pagination.total_pages;
                            this.totalItem = data.meta.pagination.total;
                        }
                    }, 100 );
                } );
        } );

    }
    
    filterItemsamecheck(searchTerm){
        return this.filterItemsamedata.filter((item) => {
            return item.container_id.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
        });
    }
    filterItemsame(searchTerm){
        // console.log(searchTerm,this.filterItemsamecheck(searchTerm));
        // return this.cDetails.filter((item) => {
        //     let searchItem: string = item.container_id;
        //     let searchItem1: string = searchTerm;
        //     return searchItem.toLowerCase().indexOf(searchItem1.toLowerCase()) > -1;
        // });    
    }

    imageEPath(id,img){
        return this.containerService.imageEPath()+"/"+id+"/"+img;
    }

    getImageLibrary(id,name){
        
        let loading = this.loadingCtrl.create( {
            content: `Please wait...`
        } );
        loading.present();
        this.containerService.setHeaders().then(() => {
             this.containerService.examinedChapter(id).subscribe(( data: any ) => {
                // console.log(data.length);
                this.title = name;
                this.cDetails = data;
                // this.chapterHeading = true;
                this.navCtrl.push(ChapterWiseDetailPage,{data:data.data,title:name});
                // this.ochDetails = data.data;
                loading.dismiss();
            } );
        } );
    }
    
    home(){
        this.navCtrl.setRoot( HomePage );
    }
    openPage(page: PageInterface) {
        let params = {};

        if (page.index) {
            params = { tabIndex: page.index };
        }
        this.navCtrl.push(page.name, params).catch((err: any) => {
            console.log(`Didn't set nav root: ${err}`);
        });
        if (page.logsOut === true) {
            // Give the menu time to close before changing to logged out
            this.userData.logout();
        }
    }

    openModal() {
    let obj = {filter: 'examined'};
        let myModal = this.modalCtrl.create(ContainerFilterPage,obj);
        myModal.onDidDismiss(keyword => {
            if(keyword != undefined){
                 let monthNames = ["January", "February", "March", "April", "May", "June",
                        "July", "August", "September", "October", "November", "December"];
                this.keyword = keyword;
                this.keyword = this.keyword.split('&');
                let keywords="";
                for(let i=0;i<this.keyword.length;i++){
                    let kk = this.keyword[i].split("=");
                    if(kk[0] == "container_number")
                    {
                        keywords +=' / '+ "Container No. - " + kk[1];
                    }
                    if(kk[0] == "scanned_date")
                    {
                        let d = new Date(kk[1]);
                        keywords +=' / '+ "Scanned Date - " + monthNames[d.getMonth()];
                    }
                    if(kk[0] == "shift")
                    {
                        keywords +=' / '+ "Shift - " + kk[1];
                    }
                    if(kk[0] == "date_of_examination")
                    {
                        keywords +=' / '+ "Date of Examination - " + kk[1];
                    }
                    //keywords +=' / '+this.keyword[i].replace('=', ' - ');
                }
                this.keyword = keywords;
                let loading = this.loadingCtrl.create( {
                content: `Please wait...`
            } );
            loading.present();
            this.containerService.setHeaders().then(() => {
                this.containerService.filterExamined(keyword).subscribe(( data: any ) => {
                this.cDetails = data.data;
                    if ( data.meta ) {
                        this.noOfPages = data.meta.pagination.total_pages;
                        this.totalItem = data.meta.pagination.total;
                    }
                loading.dismiss();
                } );
            } );
            
            }
        });
        myModal.present();
    }
}
