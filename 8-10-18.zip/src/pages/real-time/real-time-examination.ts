import { Component } from '@angular/core';
import {
    NavController,
    LoadingController,
} from 'ionic-angular';

import { ReportService } from '../../providers/report.service';
import { UserService } from '../../providers/user-service';
import { HomePage } from '../home/home';

import { BasePage } from '../base-page';
import { PageInterface } from '../../app/app.component';
import { UserData } from '../../providers/user-data';

import { ContainerFilterPage } from '../container-filter/container-filter';

@Component( {
    selector: 'page-real-time-examination',
    templateUrl: 'real-time-examination.html'
} )
export class RealTimeExaminationPage extends BasePage{
    session: any;
    cfs: any;
    scanned: any;
    page = 1;
    noOfPages = 0;
    totalItem = 0;
    keyword:any;
    searching: any = false;
    searchTerm: string = '';
    date_month = "";
    constructor(
        public reportService: ReportService,
        private navController: NavController,
        public loadingCtrl: LoadingController,
        public user: UserService,
        public userData: UserData,
    ) {
        super( user, navController );
        this.cfs = [];
        this.scanned = [];
    }

    ionViewWillEnter() {
        let loading = this.loadingCtrl.create( {
            content: `Please wait...`
        } );
        loading.present();
        this.reportService.setHeaders().then(() => {
            this.reportService.loadRealTimeCFS(this.page,this.date_month)
                .subscribe(( data: any ) => {
                    this.cfs = this.cfs.concat( data.data );
                    if ( data.meta ) {
                        this.noOfPages = data.meta.pagination.total_pages;
                        this.totalItem = data.meta.pagination.total;
                    }
                    // console.log(this.noOfPages);
                   loading.dismiss();
                } );
            // this.reportService.loadRealTimeScanned()
            //     .subscribe(( data: any ) => {
            //         this.scanned = this.scanned.concat( data.data );
            //         if ( data.meta ) {
            //             this.noOfPages = data.meta.pagination.total_pages;
            //             this.totalItem = data.meta.pagination.total;
            //         }
            //         loading.dismiss();
            //     } );
        } );
           
    }
     doInfinite( infiniteScroll: any ) {
        this.page += 1;
        if ( this.page > this.noOfPages ) {
            infiniteScroll.complete();
            return false;
        }
        this.reportService.setHeaders().then(() => {
            this.reportService.loadRealTimeCFS(this.page,this.date_month)
                .subscribe(( data: any ) => {
                     setTimeout(() => {
                        infiniteScroll.complete();
                    this.cfs = this.cfs.concat( data.data );
                    if ( data.meta ) {
                        this.noOfPages = data.meta.pagination.total_pages;
                        this.totalItem = data.meta.pagination.total;
                    }
                     }, 100);
                } );
     });
     }
    home(){
        this.navController.setRoot( HomePage );
    }

    changeDate(reportDate){
        this.date_month = reportDate;
        let loading = this.loadingCtrl.create( {
            content: `Please wait...`
        } );
        loading.present();
     this.reportService.loadRealTimeCFS(this.page=1,reportDate+"-01")
                .subscribe(( data: any ) => {
                    this.cfs =  data.data;
                    if ( data.meta ) {
                        this.noOfPages = data.meta.pagination.total_pages;
                        this.totalItem = data.meta.pagination.total;
                    }
                   loading.dismiss();
                } );
    }
    openPage(page: PageInterface) {
        let params = {};

        if (page.index) {
            params = { tabIndex: page.index };
        }
        this.navController.push(page.name, params).catch((err: any) => {
            console.log(`Didn't set nav root: ${err}`);
        });
        if (page.logsOut === true) {
            // Give the menu time to close before changing to logged out
            this.userData.logout();
        }
    }

     onSearchInput(){
        this.searching = true;
    }

 
}
