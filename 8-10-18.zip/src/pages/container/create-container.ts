
import { Component, OnInit } from '@angular/core';
import {
    NavController,
    ToastController,
    LoadingController,
    Loading
} from 'ionic-angular';
import { ContainerService } from '../../providers/container.service';
import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms'
import { ContainerPage } from '../container/container';

@Component( {
    selector: 'page-create-container',
    templateUrl: 'create-container.html'
} )
export class CreateContainerPage implements OnInit {
    title = 'Create Container';
    formData: FormGroup;
    loading: Loading;
    constructor(
        public containerService: ContainerService,
        private fb: FormBuilder,
        public navCtrl: NavController,
        public toastCtrl: ToastController,
        public loadingCtrl: LoadingController
    ) {
        this.formData = this.fb.group( {
            igm_number: new FormControl( '', Validators.required ),
            cfs_name: new FormControl( '', Validators.required ),
            container_number: new FormControl( '', Validators.required ),
            description: new FormControl( '', Validators.required ),
            user_id: new FormControl( '', Validators.required ),
        } );
    }
    ngOnInit() {
        this.formData.get( 'user_id' ).setValue( 1 );
    }
    submit() {
        if ( this.formData.valid ) {
            let loading = this.loadingCtrl.create( {
                content: `Please wait...`
            } );
            loading.present();
            this.containerService.setHeaders().then(() => {
                this.containerService.createContainer( this.formData.value )
                    .subscribe(() => {
                        loading.dismiss();

                        this.showToast( 'Created successfully.' );
                        this.navCtrl.push( ContainerPage );

                    }, ( er: any ) => {
                        loading.dismiss();
                        this.showToast( 'Something went wrong.' + er.error );
                    } );
            } );
        } else {
            Object.keys( this.formData.controls ).forEach( field => { // {1}
                const control = this.formData.get( field );            // {2}
                control.markAsTouched( { onlySelf: true } );       // {3}
            } );
        }
    }

    private showToast( msg ) {
        let toast = this.toastCtrl.create( {
            message: msg,
            duration: 3000,
            position: 'bottom'
        } );
        toast.present();
    }
    setBackButtonAction() {
        this.navCtrl.setRoot( ContainerPage );
    }
}
