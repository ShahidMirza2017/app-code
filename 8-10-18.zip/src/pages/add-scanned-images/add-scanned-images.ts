import { Component, OnInit } from '@angular/core';
import {
    NavController,
    ActionSheetController,
    ToastController,
    Platform,
    LoadingController,
    Loading
} from 'ionic-angular';
import { ContainerService } from '../../providers/container.service';
import { UserData } from '../../providers/user-data';
import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms'
import { FilePath } from '@ionic-native/file-path';
import { Camera } from '@ionic-native/camera';
import { File } from '@ionic-native/file';
import { ImagePicker } from '@ionic-native/image-picker';
import { Base64 } from '@ionic-native/base64';
import { ScannedImagesPage } from '../scanned-images/scanned-images';
declare var cordova: any;

@Component({
    selector: 'page-add-scanned-images',
    templateUrl: 'add-scanned-images.html'
})
export class AddScannedmagesPage implements OnInit {
    title = 'Add Scanned Images';
    formData: FormGroup;
    container_img: any;
    scannedData: any;
    cDetails: any =[];
    addform:any = false;
    aip:any =false;
    aip1:any =true;
    
    page = 1;
    
    // image
    lastImage: string = null;
    loading: Loading;
    constructor(
        public containerService: ContainerService,
        private fb: FormBuilder,
        public navCtrl: NavController,
        private camera: Camera,
        private imagePicker: ImagePicker,
        private file: File,
        private filePath: FilePath,
        public actionSheetCtrl: ActionSheetController,
        public toastCtrl: ToastController,
        public platform: Platform,
        public loadingCtrl: LoadingController,
        private userData: UserData
    ) {
        this.formData = this.fb.group({
            container_id: new FormControl('', Validators.required),
            user_id: new FormControl('', Validators.required),
            // cfs_name: new FormControl('', Validators.required),
            scanning_result: new FormControl('', Validators.required),
            scanner_type: new FormControl('', Validators.required),
            'files[]': new FormControl('', Validators.required),
            scanning_date: new FormControl('', Validators.required),
            shift: new FormControl('', Validators.required),
            is_special_watch: new FormControl('', Validators.required),
            query1: new FormControl( '', Validators.required ),
        });
        this.formData.get( 'query1' ).setValue( "sdfsd");
         
    }
    ionViewWillEnter() {
        let loading = this.loadingCtrl.create( {
            content: `Please wait...`
        } );
        loading.present();
        this.containerService.setHeaders().then(() => {
            this.containerService.getScannedImages()
                .subscribe(( data: any ) => {
                    this.cDetails = this.cDetails.concat( data.data );
                    
                    loading.dismiss();
                } );
        } );
            
    }
    doInfinite( infiniteScroll: any ) {
        this.page += 1;
        this.containerService.setHeaders().then(() => {
            this.containerService.getScannedImages( this.page ).subscribe(( data: any ) => {
                setTimeout(() => {
                    infiniteScroll.complete();
                    this.cDetails = this.cDetails.concat( data.data );
                   
                }, 100 );
            } );
        } );

    }
    addoForm(){
        this.addform =true;
    }
    addForm(item){
        this.addform =true;
        this.aip = true;
        this.aip1 =false;
        this.formData.get( 'query1' ).setValue( item.container.container_number +'=> IGM Number:' + item.container.igm_number + '=> CFS Name:' + item.container.cfs_name); 
        console.log(item.container.id);
        this.formData.get( 'container_id' ).setValue( item.container.id ); 
        this.container_img = item.image;
        this.scannedData = item;
        this.userData.getUserId().then(( id ) => {
            this.formData.get( 'user_id' ).setValue( id );
        } );
    }
    ngOnInit() {

    }
    onSelected(item: any) {
        new Date();
        this.formData.get('container_id').setValue(item['id']);
        this.container_img = item.scannedImage.data.image;
        this.userData.getUserId().then((id) => {
            this.formData.get('user_id').setValue(id);
        });
        // this.formData.get('cfs_name').setValue(item.cfs_name);
        this.formData.get('is_special_watch').setValue(0);
        this.formData.get('scanning_date').setValue(new Date().toJSON().slice(0, 10).replace(/-/g, '/'));
    }
    submit() {
        if (this.formData.valid) {
            this.uploadDataAndImages(this.formData.value);
        } else {
            Object.keys(this.formData.controls).forEach(field => { // {1}
                const control = this.formData.get(field);            // {2}
                control.markAsTouched({ onlySelf: true });       // {3}
            });
        }
    }

    uploadDataAndImages(data: any): any {
        this.loading = this.loadingCtrl.create({
            content: 'Uploading..',
        });
        this.loading.present();
        const completePath = this.pathForImage(data['files[]']);
        this.containerService.setHeaders().then((token) => {
            this.containerService.uploadScannedImages(data, completePath, token).then(() => {
                this.loading.dismissAll();
                this.formData.reset();
                this.navCtrl.push(ScannedImagesPage);
                this.presentToast('Data uploaded successfully.');
            }, () => {
                this.loading.dismissAll()
                this.presentToast('Error while uploading file/Image is too big.');
            });
        });
    }
    public presentActionSheet() {
        let actionSheet = this.actionSheetCtrl.create({
            title: 'Image Source',
            buttons: [
                {
                    text: 'Gallery',
                    handler: () => {
                        this.takePicture(this.camera.PictureSourceType.PHOTOLIBRARY);
                    }
                },
                // {
                //     text: 'Camera',
                //     handler: () => {
                //         this.takePicture(this.camera.PictureSourceType.CAMERA);
                //     }
                // },
                {
                    text: 'Cancel',
                    role: 'cancel'
                }
            ]
        });
        actionSheet.present();
    }
    public takePicture(sourceType) {
        // Create options for the Camera Dialog
        var options = {
            quality: 100,
            sourceType: sourceType,
            saveToPhotoAlbum: false,
            correctOrientation: true
        };

        // Get the data of an image
        this.camera.getPicture(options).then((imagePath) => {
            // Special handling for Android library
            if (this.platform.is('android') && sourceType === this.camera.PictureSourceType.PHOTOLIBRARY) {
                this.filePath.resolveNativePath(imagePath)
                    .then(filePath => {
                        let correctPath = filePath.substr(0, filePath.lastIndexOf('/') + 1);
                        let currentName = imagePath.substring(imagePath.lastIndexOf('/') + 1, imagePath.lastIndexOf('?'));
                        this.copyFileToLocalDir(correctPath, currentName, this.createFileName());
                    });
            } else {
                var currentName = imagePath.substr(imagePath.lastIndexOf('/') + 1);
                var correctPath = imagePath.substr(0, imagePath.lastIndexOf('/') + 1);
                this.copyFileToLocalDir(correctPath, currentName, this.createFileName());
            }
        }, (err) => {
            console.log('Error Data');
            console.log(err);
            this.presentToast('Error while selecting image.');
        });
    }
    isValid(key, validation = 'required') {
        return this.formData.get(key).hasError(validation) &&
            (this.formData.get(key).dirty ||
                this.formData.get(key).touched)
    }
    private createFileName() {
        var d = new Date(),
            n = d.getTime(),
            newFileName = n + ".jpg";
        return newFileName;
    }

    // Copy the image to a local folder
    private copyFileToLocalDir(namePath, currentName, newFileName) {
        this.file.copyFile(namePath, currentName, cordova.file.dataDirectory, newFileName).then(success => {
            console.log('Success Data');
            console.log(success);
            this.lastImage = newFileName;
            this.lastImage = newFileName;
            this.formData.get('files[]').setValue(this.lastImage);
        }, error => {
            console.log('add-scanned-images :: copyFileToLocalDir :: Error Data');

            console.log(error);
            this.presentToast('Error while storing file.');
        });
    }

    private presentToast(text) {
        let toast = this.toastCtrl.create({
            message: text,
            duration: 3000,
            position: 'bottom'
        });
        toast.present();
    }

    // Always get the accurate path to your apps folder
    public pathForImage(img) {
        if (img === null) {
            return '';
        } else {
            return cordova.file.dataDirectory + img;
        }
    }
}
