import { ElementRef, Component, EventEmitter, Output, Input } from '@angular/core';
import { ContainerService } from '../../providers/container.service';
import { LoadingController } from 'ionic-angular';
@Component( {
    selector: 'chapterautocomplete',
    host: {
        '(document:click)': 'handleClick($event)',
    },
    templateUrl: 'chapter-auto-complete.html'
} )
export class ChapterAutocompleteComponent {
    public query = '';
    public filteredList: any;
    public isdataavalialble = false;
    public elementRef;
    @Input() title = "Chapter Heading";
    @Output() selected: EventEmitter<any> = new EventEmitter();
    constructor(
        myElement: ElementRef,
        private containerService: ContainerService,
       public loadingCtrl: LoadingController,
    ) {
        this.elementRef = myElement;
    }
    async search() {
        let loading = this.loadingCtrl.create( {
            content: `Please wait...`
        } );
        loading.present();
        if ( this.query !== "" ) {
            this.containerService.setHeaders().then(() => {
                this.containerService.searchChapterheading( this.query ).subscribe(( data: any ) => {
                    this.filteredList = data.data;
                   loading.dismiss();
                    if ( data.data.length > 0 ) {
                        this.isdataavalialble = true;
                    } else {
                        this.isdataavalialble = false;
                    }
                } );
            } );
        } else {
            loading.dismiss();
            this.isdataavalialble = false;
            this.filteredList = false;
        }
    }

    select( item: any ) {
        this.query = item['name'];
        this.filteredList = false;
        this.selected.emit( item );
    }
    eselect( item: any ) {
        this.query = item['name'];
        this.filteredList = false;
        this.selected.emit( item );
    }
    handleClick( event ) {
        var clickedComponent = event.target;
        var inside = false;
        do {
            if ( clickedComponent === this.elementRef.nativeElement ) {
                inside = true;
            }
            clickedComponent = clickedComponent.parentNode;
        } while ( clickedComponent );
        if ( !inside ) {
            this.filteredList = false;
        }
    }
}
