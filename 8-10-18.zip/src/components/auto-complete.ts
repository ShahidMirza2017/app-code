import { ElementRef, Component, EventEmitter, Output, Input } from '@angular/core';
import { ContainerService } from '../providers/container.service';
//import { LoadingController } from 'ionic-angular';
@Component( {
    selector: 'autocomplete',
    host: {
        '(document:click)': 'handleClick($event)',
    },
    templateUrl: 'auto-complete.html'
} )
export class AutocompleteComponent {
    public query = '';
    public filteredList: any;
    public isdataavalialble = false;
    public elementRef;
    @Input() title = "Container number with IGM no";
    @Output() selected: EventEmitter<any> = new EventEmitter();
    constructor(
        myElement: ElementRef,
        private containerService: ContainerService,
  //      public loadingCtrl: LoadingController,
    ) {
        this.elementRef = myElement;
    }
    async search() {
        // let loading = this.loadingCtrl.create( {
        //     content: `Please wait...`
        // } );
        //loading.present();
        if ( this.query !== "" ) {
            this.containerService.setHeaders().then(() => {
                this.containerService.searchContainer( this.query ).subscribe(( data: any ) => {
                    this.filteredList = data.data;
          //          loading.dismiss();
                    if ( data.data.length > 0 ) {
                        this.isdataavalialble = true;
                    } else {
                        this.isdataavalialble = false;
                    }
                } );
            } );
        } else {
            //loading.dismiss();
            this.isdataavalialble = false;
            this.filteredList = false;
        }
    }

    select( item: any ) {
        this.query = item['container_number'] + '=> IGM Number:' + item['igm_number'] + '=> CFS Name:' + item['cfs_name'];
        this.filteredList = false;
        this.selected.emit( item );
    }
    handleClick( event ) {
        var clickedComponent = event.target;
        var inside = false;
        do {
            if ( clickedComponent === this.elementRef.nativeElement ) {
                inside = true;
            }
            clickedComponent = clickedComponent.parentNode;
        } while ( clickedComponent );
        if ( !inside ) {
            this.filteredList = false;
        }
    }
}
