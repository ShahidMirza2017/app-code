
export interface UserOptions {
  employee_id: string,
  email: string,
  password: string
}
